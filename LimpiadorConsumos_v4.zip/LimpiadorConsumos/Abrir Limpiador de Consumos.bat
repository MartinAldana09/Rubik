@echo off
setlocal
title Limpiador de Consumos
rem ------------------------------------------------------------------
rem  Arrancador del Limpiador de Consumos (SMS, Mailing y WhatsApp).
rem  Abre la app como ventana propia en Edge o Chrome; si no los
rem  encuentra, la abre en el navegador predeterminado. No instala nada.
rem ------------------------------------------------------------------
set "APP=%~dp0app\index.html"
if not exist "%APP%" (
  echo.
  echo   No se encontro la carpeta app. Descomprima el ZIP completo
  echo   y vuelva a abrir este archivo desde la carpeta LimpiadorConsumos.
  echo.
  pause
  exit /b 1
)
set "URL=file:///%APP:\=/%"

set "EDGE=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
if not exist "%EDGE%" set "EDGE=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
if exist "%EDGE%" (
  start "" "%EDGE%" --app="%URL%" --window-size=1280,900
  exit /b 0
)

set "CHROME=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
if not exist "%CHROME%" set "CHROME=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
if not exist "%CHROME%" set "CHROME=%LocalAppData%\Google\Chrome\Application\chrome.exe"
if exist "%CHROME%" (
  start "" "%CHROME%" --app="%URL%" --window-size=1280,900
  exit /b 0
)

start "" "%APP%"
exit /b 0
