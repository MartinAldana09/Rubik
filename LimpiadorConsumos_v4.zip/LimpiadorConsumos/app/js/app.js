/* Limpiador de Consumos · interfaz */
(function () {
  'use strict';
  var E = window.ConsumosEngine;
  var EJEMPLO = {"filas":[{"FUENTE":"OMNI_WA","ARCHIVO":"omniexperienciacontact 1 a 15 septiembre.xls","FECHA":"2026-09-01","CAMPAÑA":"Asistente Virtual","VALOR_ORIGEN":"Interacciones","ESTADO":"Interacción","ES_FACTURABLE":1,"CANTIDAD":15261,"REGISTROS":15261,"HOJA":"WA_Omniexperiencia","AÑO":2026,"NRO_MES":9,"MES":"Septiembre","PROVEEDOR":"OMNIEXPERIENCIA (Celeste MedPlus)","CAMPAÑA_PROVEEDOR":"Chatbot","Search_Key":"Medplus_Asistente Virtual_Chatbot [Cada respuesta]","CLIENTE":"MedPlus","SERVICIO":"Chatbot [Cada respuesta]","CANAL":"Chatbot","HOMOLOGACION":"Homologado","NOTA_HOMOLOGACION":"","SUBCANAL":"WhatsApp","UNIDAD":"Respuesta bot","FECHA_CORTE":"2026-09-28","LOTE":202610012100},{"FUENTE":"OMNI_WA","ARCHIVO":"omniexperienciacontact 1 a 15 septiembre.xls","FECHA":"2026-09-02","CAMPAÑA":"Asistente Virtual","VALOR_ORIGEN":"Interacciones","ESTADO":"Interacción","ES_FACTURABLE":1,"CANTIDAD":22229,"REGISTROS":22229,"HOJA":"WA_Omniexperiencia","AÑO":2026,"NRO_MES":9,"MES":"Septiembre","PROVEEDOR":"OMNIEXPERIENCIA (Celeste MedPlus)","CAMPAÑA_PROVEEDOR":"Chatbot","Search_Key":"Medplus_Asistente Virtual_Chatbot [Cada respuesta]","CLIENTE":"MedPlus","SERVICIO":"Chatbot [Cada respuesta]","CANAL":"Chatbot","HOMOLOGACION":"Homologado","NOTA_HOMOLOGACION":"","SUBCANAL":"WhatsApp","UNIDAD":"Respuesta bot","FECHA_CORTE":"2026-09-28","LOTE":202610012100},{"FUENTE":"OMNI_WA","ARCHIVO":"omniexperienciacontact 1 a 15 septiembre.xls","FECHA":"2026-09-03","CAMPAÑA":"Asistente Virtual","VALOR_ORIGEN":"Interacciones","ESTADO":"Interacción","ES_FACTURABLE":1,"CANTIDAD":19660,"REGISTROS":19660,"HOJA":"WA_Omniexperiencia","AÑO":2026,"NRO_MES":9,"MES":"Septiembre","PROVEEDOR":"OMNIEXPERIENCIA (Celeste MedPlus)","CAMPAÑA_PROVEEDOR":"Chatbot","Search_Key":"Medplus_Asistente Virtual_Chatbot [Cada respuesta]","CLIENTE":"MedPlus","SERVICIO":"Chatbot [Cada respuesta]","CANAL":"Chatbot","HOMOLOGACION":"Homologado","NOTA_HOMOLOGACION":"","SUBCANAL":"WhatsApp","UNIDAD":"Respuesta bot","FECHA_CORTE":"2026-09-28","LOTE":202610012100},{"FUENTE":"OMNI_WA","ARCHIVO":"omniexperienciacontact 1 a 15 septiembre.xls","FECHA":"2026-09-04","CAMPAÑA":"Asistente Virtual","VALOR_ORIGEN":"Interacciones","ESTADO":"Interacción","ES_FACTURABLE":1,"CANTIDAD":18427,"REGISTROS":18427,"HOJA":"WA_Omniexperiencia","AÑO":2026,"NRO_MES":9,"MES":"Septiembre","PROVEEDOR":"OMNIEXPERIENCIA (Celeste MedPlus)","CAMPAÑA_PROVEEDOR":"Chatbot","Search_Key":"Medplus_Asistente Virtual_Chatbot [Cada respuesta]","CLIENTE":"MedPlus","SERVICIO":"Chatbot [Cada respuesta]","CANAL":"Chatbot","HOMOLOGACION":"Homologado","NOTA_HOMOLOGACION":"","SUBCANAL":"WhatsApp","UNIDAD":"Respuesta bot","FECHA_CORTE":"2026-09-28","LOTE":202610012100},{"FUENTE":"OMNI_WA","ARCHIVO":"omniexperienciacontact 1 a 15 septiembre.xls","FECHA":"2026-09-05","CAMPAÑA":"Asistente Virtual","VALOR_ORIGEN":"Interacciones","ESTADO":"Interacción","ES_FACTURABLE":1,"CANTIDAD":10375,"REGISTROS":10375,"HOJA":"WA_Omniexperiencia","AÑO":2026,"NRO_MES":9,"MES":"Septiembre","PROVEEDOR":"OMNIEXPERIENCIA (Celeste MedPlus)","CAMPAÑA_PROVEEDOR":"Chatbot","Search_Key":"Medplus_Asistente Virtual_Chatbot [Cada respuesta]","CLIENTE":"MedPlus","SERVICIO":"Chatbot [Cada respuesta]","CANAL":"Chatbot","HOMOLOGACION":"Homologado","NOTA_HOMOLOGACION":"","SUBCANAL":"WhatsApp","UNIDAD":"Respuesta bot","FECHA_CORTE":"2026-09-28","LOTE":202610012100},{"FUENTE":"OMNI_WA","ARCHIVO":"omniexperienciacontact 1 a 15 septiembre.xls","FECHA":"2026-09-06","CAMPAÑA":"Asistente Virtual","VALOR_ORIGEN":"Interacciones","ESTADO":"Interacción","ES_FACTURABLE":1,"CANTIDAD":8956,"REGISTROS":8956,"HOJA":"WA_Omniexperiencia","AÑO":2026,"NRO_MES":9,"MES":"Septiembre","PROVEEDOR":"OMNIEXPERIENCIA (Celeste MedPlus)","CAMPAÑA_PROVEEDOR":"Chatbot","Search_Key":"Medplus_Asistente Virtual_Chatbot [Cada respuesta]","CLIENTE":"MedPlus","SERVICIO":"Chatbot [Cada respuesta]","CANAL":"Chatbot","HOMOLOGACION":"Homologado","NOTA_HOMOLOGACION":"","SUBCANAL":"WhatsApp","UNIDAD":"Respuesta bot","FECHA_CORTE":"2026-09-28","LOTE":202610012100},{"FUENTE":"OMNI_WA","ARCHIVO":"omniexperienciacontact 1 a 15 septiembre.xls","FECHA":"2026-09-07","CAMPAÑA":"Asistente Virtual","VALOR_ORIGEN":"Interacciones","ESTADO":"Interacción","ES_FACTURABLE":1,"CANTIDAD":22088,"REGISTROS":22088,"HOJA":"WA_Omniexperiencia","AÑO":2026,"NRO_MES":9,"MES":"Septiembre","PROVEEDOR":"OMNIEXPERIENCIA (Celeste MedPlus)","CAMPAÑA_PROVEEDOR":"Chatbot","Search_Key":"Medplus_Asistente Virtual_Chatbot [Cada respuesta]","CLIENTE":"MedPlus","SERVICIO":"Chatbot [Cada respuesta]","CANAL":"Chatbot","HOMOLOGACION":"Homologado","NOTA_HOMOLOGACION":"","SUBCANAL":"WhatsApp","UNIDAD":"Respuesta bot","FECHA_CORTE":"2026-09-28","LOTE":202610012100},{"FUENTE":"OMNI_WA","ARCHIVO":"omniexperienciacontact 1 a 15 septiembre.xls","FECHA":"2026-09-08","CAMPAÑA":"Asistente Virtual","VALOR_ORIGEN":"Interacciones","ESTADO":"Interacción","ES_FACTURABLE":1,"CANTIDAD":23982,"REGISTROS":23982,"HOJA":"WA_Omniexperiencia","AÑO":2026,"NRO_MES":9,"MES":"Septiembre","PROVEEDOR":"OMNIEXPERIENCIA (Celeste MedPlus)","CAMPAÑA_PROVEEDOR":"Chatbot","Search_Key":"Medplus_Asistente Virtual_Chatbot [Cada respuesta]","CLIENTE":"MedPlus","SERVICIO":"Chatbot [Cada respuesta]","CANAL":"Chatbot","HOMOLOGACION":"Homologado","NOTA_HOMOLOGACION":"","SUBCANAL":"WhatsApp","UNIDAD":"Respuesta bot","FECHA_CORTE":"2026-09-28","LOTE":202610012100},{"FUENTE":"OMNI_WA","ARCHIVO":"omniexperienciacontact 1 a 15 septiembre.xls","FECHA":"2026-09-09","CAMPAÑA":"Asistente Virtual","VALOR_ORIGEN":"Interacciones","ESTADO":"Interacción","ES_FACTURABLE":1,"CANTIDAD":20092,"REGISTROS":20092,"HOJA":"WA_Omniexperiencia","AÑO":2026,"NRO_MES":9,"MES":"Septiembre","PROVEEDOR":"OMNIEXPERIENCIA (Celeste MedPlus)","CAMPAÑA_PROVEEDOR":"Chatbot","Search_Key":"Medplus_Asistente Virtual_Chatbot [Cada respuesta]","CLIENTE":"MedPlus","SERVICIO":"Chatbot [Cada respuesta]","CANAL":"Chatbot","HOMOLOGACION":"Homologado","NOTA_HOMOLOGACION":"","SUBCANAL":"WhatsApp","UNIDAD":"Respuesta bot","FECHA_CORTE":"2026-09-28","LOTE":202610012100},{"FUENTE":"OMNI_WA","ARCHIVO":"omniexperienciacontact 1 a 15 septiembre.xls","FECHA":"2026-09-10","CAMPAÑA":"Asistente Virtual","VALOR_ORIGEN":"Interacciones","ESTADO":"Interacción","ES_FACTURABLE":1,"CANTIDAD":19412,"REGISTROS":19412,"HOJA":"WA_Omniexperiencia","AÑO":2026,"NRO_MES":9,"MES":"Septiembre","PROVEEDOR":"OMNIEXPERIENCIA (Celeste MedPlus)","CAMPAÑA_PROVEEDOR":"Chatbot","Search_Key":"Medplus_Asistente Virtual_Chatbot [Cada respuesta]","CLIENTE":"MedPlus","SERVICIO":"Chatbot [Cada respuesta]","CANAL":"Chatbot","HOMOLOGACION":"Homologado","NOTA_HOMOLOGACION":"","SUBCANAL":"WhatsApp","UNIDAD":"Respuesta bot","FECHA_CORTE":"2026-09-28","LOTE":202610012100},{"FUENTE":"OMNI_WA","ARCHIVO":"omniexperienciacontact 1 a 15 septiembre.xls","FECHA":"2026-09-11","CAMPAÑA":"Asistente Virtual","VALOR_ORIGEN":"Interacciones","ESTADO":"Interacción","ES_FACTURABLE":1,"CANTIDAD":19829,"REGISTROS":19829,"HOJA":"WA_Omniexperiencia","AÑO":2026,"NRO_MES":9,"MES":"Septiembre","PROVEEDOR":"OMNIEXPERIENCIA (Celeste MedPlus)","CAMPAÑA_PROVEEDOR":"Chatbot","Search_Key":"Medplus_Asistente Virtual_Chatbot [Cada respuesta]","CLIENTE":"MedPlus","SERVICIO":"Chatbot [Cada respuesta]","CANAL":"Chatbot","HOMOLOGACION":"Homologado","NOTA_HOMOLOGACION":"","SUBCANAL":"WhatsApp","UNIDAD":"Respuesta bot","FECHA_CORTE":"2026-09-28","LOTE":202610012100},{"FUENTE":"OMNI_WA","ARCHIVO":"omniexperienciacontact 1 a 15 septiembre.xls","FECHA":"2026-09-12","CAMPAÑA":"Asistente Virtual","VALOR_ORIGEN":"Interacciones","ESTADO":"Interacción","ES_FACTURABLE":1,"CANTIDAD":5879,"REGISTROS":5879,"HOJA":"WA_Omniexperiencia","AÑO":2026,"NRO_MES":9,"MES":"Septiembre","PROVEEDOR":"OMNIEXPERIENCIA (Celeste MedPlus)","CAMPAÑA_PROVEEDOR":"Chatbot","Search_Key":"Medplus_Asistente Virtual_Chatbot [Cada respuesta]","CLIENTE":"MedPlus","SERVICIO":"Chatbot [Cada respuesta]","CANAL":"Chatbot","HOMOLOGACION":"Homologado","NOTA_HOMOLOGACION":"","SUBCANAL":"WhatsApp","UNIDAD":"Respuesta bot","FECHA_CORTE":"2026-09-28","LOTE":202610012100},{"FUENTE":"OMNI_WA","ARCHIVO":"omniexperienciacontact 1 a 15 septiembre.xls","FECHA":"2026-09-13","CAMPAÑA":"Asistente Virtual","VALOR_ORIGEN":"Interacciones","ESTADO":"Interacción","ES_FACTURABLE":1,"CANTIDAD":2666,"REGISTROS":2666,"HOJA":"WA_Omniexperiencia","AÑO":2026,"NRO_MES":9,"MES":"Septiembre","PROVEEDOR":"OMNIEXPERIENCIA (Celeste MedPlus)","CAMPAÑA_PROVEEDOR":"Chatbot","Search_Key":"Medplus_Asistente Virtual_Chatbot [Cada respuesta]","CLIENTE":"MedPlus","SERVICIO":"Chatbot [Cada respuesta]","CANAL":"Chatbot","HOMOLOGACION":"Homologado","NOTA_HOMOLOGACION":"","SUBCANAL":"WhatsApp","UNIDAD":"Respuesta bot","FECHA_CORTE":"2026-09-28","LOTE":202610012100},{"FUENTE":"OMNI_WA","ARCHIVO":"omniexperienciacontact 1 a 15 septiembre.xls","FECHA":"2026-09-14","CAMPAÑA":"Asistente Virtual","VALOR_ORIGEN":"Interacciones","ESTADO":"Interacción","ES_FACTURABLE":1,"CANTIDAD":16898,"REGISTROS":16898,"HOJA":"WA_Omniexperiencia","AÑO":2026,"NRO_MES":9,"MES":"Septiembre","PROVEEDOR":"OMNIEXPERIENCIA (Celeste MedPlus)","CAMPAÑA_PROVEEDOR":"Chatbot","Search_Key":"Medplus_Asistente Virtual_Chatbot [Cada respuesta]","CLIENTE":"MedPlus","SERVICIO":"Chatbot [Cada respuesta]","CANAL":"Chatbot","HOMOLOGACION":"Homologado","NOTA_HOMOLOGACION":"","SUBCANAL":"WhatsApp","UNIDAD":"Respuesta bot","FECHA_CORTE":"2026-09-28","LOTE":202610012100},{"FUENTE":"OMNI_WA","ARCHIVO":"omniexperienciacontact 1 a 15 septiembre.xls","FECHA":"2026-09-15","CAMPAÑA":"Asistente Virtual","VALOR_ORIGEN":"Interacciones","ESTADO":"Interacción","ES_FACTURABLE":1,"CANTIDAD":15764,"REGISTROS":15764,"HOJA":"WA_Omniexperiencia","AÑO":2026,"NRO_MES":9,"MES":"Septiembre","PROVEEDOR":"OMNIEXPERIENCIA (Celeste MedPlus)","CAMPAÑA_PROVEEDOR":"Chatbot","Search_Key":"Medplus_Asistente Virtual_Chatbot [Cada respuesta]","CLIENTE":"MedPlus","SERVICIO":"Chatbot [Cada respuesta]","CANAL":"Chatbot","HOMOLOGACION":"Homologado","NOTA_HOMOLOGACION":"","SUBCANAL":"WhatsApp","UNIDAD":"Respuesta bot","FECHA_CORTE":"2026-09-28","LOTE":202610012100},{"FUENTE":"OMNI_WA","ARCHIVO":"omniexperienciacontact 16 al 28 septiembre.xls","FECHA":"2026-09-16","CAMPAÑA":"Asistente Virtual","VALOR_ORIGEN":"Interacciones","ESTADO":"Interacción","ES_FACTURABLE":1,"CANTIDAD":16682,"REGISTROS":16682,"HOJA":"WA_Omniexperiencia","AÑO":2026,"NRO_MES":9,"MES":"Septiembre","PROVEEDOR":"OMNIEXPERIENCIA (Celeste MedPlus)","CAMPAÑA_PROVEEDOR":"Chatbot","Search_Key":"Medplus_Asistente Virtual_Chatbot [Cada respuesta]","CLIENTE":"MedPlus","SERVICIO":"Chatbot [Cada respuesta]","CANAL":"Chatbot","HOMOLOGACION":"Homologado","NOTA_HOMOLOGACION":"","SUBCANAL":"WhatsApp","UNIDAD":"Respuesta bot","FECHA_CORTE":"2026-09-28","LOTE":202610012100},{"FUENTE":"OMNI_WA","ARCHIVO":"omniexperienciacontact 16 al 28 septiembre.xls","FECHA":"2026-09-17","CAMPAÑA":"Asistente Virtual","VALOR_ORIGEN":"Interacciones","ESTADO":"Interacción","ES_FACTURABLE":1,"CANTIDAD":17942,"REGISTROS":17942,"HOJA":"WA_Omniexperiencia","AÑO":2026,"NRO_MES":9,"MES":"Septiembre","PROVEEDOR":"OMNIEXPERIENCIA (Celeste MedPlus)","CAMPAÑA_PROVEEDOR":"Chatbot","Search_Key":"Medplus_Asistente Virtual_Chatbot [Cada respuesta]","CLIENTE":"MedPlus","SERVICIO":"Chatbot [Cada respuesta]","CANAL":"Chatbot","HOMOLOGACION":"Homologado","NOTA_HOMOLOGACION":"","SUBCANAL":"WhatsApp","UNIDAD":"Respuesta bot","FECHA_CORTE":"2026-09-28","LOTE":202610012100},{"FUENTE":"OMNI_WA","ARCHIVO":"omniexperienciacontact 16 al 28 septiembre.xls","FECHA":"2026-09-18","CAMPAÑA":"Asistente Virtual","VALOR_ORIGEN":"Interacciones","ESTADO":"Interacción","ES_FACTURABLE":1,"CANTIDAD":16290,"REGISTROS":16290,"HOJA":"WA_Omniexperiencia","AÑO":2026,"NRO_MES":9,"MES":"Septiembre","PROVEEDOR":"OMNIEXPERIENCIA (Celeste MedPlus)","CAMPAÑA_PROVEEDOR":"Chatbot","Search_Key":"Medplus_Asistente Virtual_Chatbot [Cada respuesta]","CLIENTE":"MedPlus","SERVICIO":"Chatbot [Cada respuesta]","CANAL":"Chatbot","HOMOLOGACION":"Homologado","NOTA_HOMOLOGACION":"","SUBCANAL":"WhatsApp","UNIDAD":"Respuesta bot","FECHA_CORTE":"2026-09-28","LOTE":202610012100},{"FUENTE":"OMNI_WA","ARCHIVO":"omniexperienciacontact 16 al 28 septiembre.xls","FECHA":"2026-09-19","CAMPAÑA":"Asistente Virtual","VALOR_ORIGEN":"Interacciones","ESTADO":"Interacción","ES_FACTURABLE":1,"CANTIDAD":5197,"REGISTROS":5197,"HOJA":"WA_Omniexperiencia","AÑO":2026,"NRO_MES":9,"MES":"Septiembre","PROVEEDOR":"OMNIEXPERIENCIA (Celeste MedPlus)","CAMPAÑA_PROVEEDOR":"Chatbot","Search_Key":"Medplus_Asistente Virtual_Chatbot [Cada respuesta]","CLIENTE":"MedPlus","SERVICIO":"Chatbot [Cada respuesta]","CANAL":"Chatbot","HOMOLOGACION":"Homologado","NOTA_HOMOLOGACION":"","SUBCANAL":"WhatsApp","UNIDAD":"Respuesta bot","FECHA_CORTE":"2026-09-28","LOTE":202610012100},{"FUENTE":"OMNI_WA","ARCHIVO":"omniexperienciacontact 16 al 28 septiembre.xls","FECHA":"2026-09-20","CAMPAÑA":"Asistente Virtual","VALOR_ORIGEN":"Interacciones","ESTADO":"Interacción","ES_FACTURABLE":1,"CANTIDAD":2953,"REGISTROS":2953,"HOJA":"WA_Omniexperiencia","AÑO":2026,"NRO_MES":9,"MES":"Septiembre","PROVEEDOR":"OMNIEXPERIENCIA (Celeste MedPlus)","CAMPAÑA_PROVEEDOR":"Chatbot","Search_Key":"Medplus_Asistente Virtual_Chatbot [Cada respuesta]","CLIENTE":"MedPlus","SERVICIO":"Chatbot [Cada respuesta]","CANAL":"Chatbot","HOMOLOGACION":"Homologado","NOTA_HOMOLOGACION":"","SUBCANAL":"WhatsApp","UNIDAD":"Respuesta bot","FECHA_CORTE":"2026-09-28","LOTE":202610012100},{"FUENTE":"NUVETO_AVI","ARCHIVO":"Nuveto_Septiembre.xlsx","FECHA":"2026-09-01","CAMPAÑA":"Atención Canales de servicio al cliente","VALOR_ORIGEN":"*","ESTADO":"Contactado","ES_FACTURABLE":1,"CANTIDAD":45,"REGISTROS":19,"HOJA":"AVI_Nuveto","AÑO":2026,"NRO_MES":9,"MES":"Septiembre","PROVEEDOR":"NUVETO","CAMPAÑA_PROVEEDOR":"Aseguramiento","Search_Key":"Medplus_Atención Canales de servicio al cliente_VoiceBot_Campañas","CLIENTE":"MedPlus","SERVICIO":"VoiceBot_Campañas","CANAL":"Voicebot (AVI)","HOMOLOGACION":"Por confirmar","NOTA_HOMOLOGACION":"Nuveto: único Search Key de voicebot en el ppto; pendiente de confirmar.","SUBCANAL":"Llamada","UNIDAD":"Minuto","FECHA_CORTE":"2026-09-28","LOTE":202610012100},{"FUENTE":"NUVETO_AVI","ARCHIVO":"Nuveto_Septiembre.xlsx","FECHA":"2026-09-01","CAMPAÑA":"Atención Canales de servicio al cliente","VALOR_ORIGEN":"*","ESTADO":"Contacto","ES_FACTURABLE":1,"CANTIDAD":121,"REGISTROS":122,"HOJA":"AVI_Nuveto","AÑO":2026,"NRO_MES":9,"MES":"Septiembre","PROVEEDOR":"NUVETO","CAMPAÑA_PROVEEDOR":"Aseguramiento","Search_Key":"Medplus_Atención Canales de servicio al cliente_VoiceBot_Campañas","CLIENTE":"MedPlus","SERVICIO":"VoiceBot_Campañas","CANAL":"Voicebot (AVI)","HOMOLOGACION":"Por confirmar","NOTA_HOMOLOGACION":"Nuveto: único Search Key de voicebot en el ppto; pendiente de confirmar.","SUBCANAL":"Llamada","UNIDAD":"Minuto","FECHA_CORTE":"2026-09-28","LOTE":202610012100},{"FUENTE":"NUVETO_AVI","ARCHIVO":"Nuveto_Septiembre.xlsx","FECHA":"2026-09-01","CAMPAÑA":"Atención Canales de servicio al cliente","VALOR_ORIGEN":"*","ESTADO":"Equivocado","ES_FACTURABLE":1,"CANTIDAD":26,"REGISTROS":42,"HOJA":"AVI_Nuveto","AÑO":2026,"NRO_MES":9,"MES":"Septiembre","PROVEEDOR":"NUVETO","CAMPAÑA_PROVEEDOR":"Aseguramiento","Search_Key":"Medplus_Atención Canales de servicio al cliente_VoiceBot_Campañas","CLIENTE":"MedPlus","SERVICIO":"VoiceBot_Campañas","CANAL":"Voicebot (AVI)","HOMOLOGACION":"Por confirmar","NOTA_HOMOLOGACION":"Nuveto: único Search Key de voicebot en el ppto; pendiente de confirmar.","SUBCANAL":"Llamada","UNIDAD":"Minuto","FECHA_CORTE":"2026-09-28","LOTE":202610012100},{"FUENTE":"NUVETO_AVI","ARCHIVO":"Nuveto_Septiembre.xlsx","FECHA":"2026-09-01","CAMPAÑA":"Atención Canales de servicio al cliente","VALOR_ORIGEN":"*","ESTADO":"No Contacto","ES_FACTURABLE":1,"CANTIDAD":409,"REGISTROS":490,"HOJA":"AVI_Nuveto","AÑO":2026,"NRO_MES":9,"MES":"Septiembre","PROVEEDOR":"NUVETO","CAMPAÑA_PROVEEDOR":"Aseguramiento","Search_Key":"Medplus_Atención Canales de servicio al cliente_VoiceBot_Campañas","CLIENTE":"MedPlus","SERVICIO":"VoiceBot_Campañas","CANAL":"Voicebot (AVI)","HOMOLOGACION":"Por confirmar","NOTA_HOMOLOGACION":"Nuveto: único Search Key de voicebot en el ppto; pendiente de confirmar.","SUBCANAL":"Llamada","UNIDAD":"Minuto","FECHA_CORTE":"2026-09-28","LOTE":202610012100},{"FUENTE":"NUVETO_AVI","ARCHIVO":"Nuveto_Septiembre.xlsx","FECHA":"2026-09-01","CAMPAÑA":"Atención Canales de servicio al cliente","VALOR_ORIGEN":"*","ESTADO":"No responde encuesta","ES_FACTURABLE":1,"CANTIDAD":53,"REGISTROS":60,"HOJA":"AVI_Nuveto","AÑO":2026,"NRO_MES":9,"MES":"Septiembre","PROVEEDOR":"NUVETO","CAMPAÑA_PROVEEDOR":"Aseguramiento","Search_Key":"Medplus_Atención Canales de servicio al cliente_VoiceBot_Campañas","CLIENTE":"MedPlus","SERVICIO":"VoiceBot_Campañas","CANAL":"Voicebot (AVI)","HOMOLOGACION":"Por confirmar","NOTA_HOMOLOGACION":"Nuveto: único Search Key de voicebot en el ppto; pendiente de confirmar.","SUBCANAL":"Llamada","UNIDAD":"Minuto","FECHA_CORTE":"2026-09-28","LOTE":202610012100}],"resumen":[{"key":"Medplus_Atención Canales de servicio al cliente_VoiceBot_Campañas","cliente":"MedPlus","canal":"Voicebot (AVI)","homolog":"Por confirmar","fuente":"NUVETO_AVI","proveedor":"NUVETO","unidad":"Minuto","fact":33174,"nofact":0,"registros":35755,"desde":"2026-08-27","hasta":"2026-09-28","mesTope":"Septiembre","tope":500,"realMes":33174},{"key":"Medplus_Asistente Virtual_Chatbot [Cada respuesta]","cliente":"MedPlus","canal":"Chatbot","homolog":"Homologado","fuente":"OMNI_WA","proveedor":"OMNIEXPERIENCIA (Celeste MedPlus)","unidad":"Respuesta bot","fact":404045,"nofact":0,"registros":404045,"desde":"2026-09-01","hasta":"2026-09-28","mesTope":"Septiembre","tope":290000,"realMes":404045},{"key":"Medplus_Asistente Virtual_Conversacion Whatsapp 24H Interaccion","cliente":"MedPlus","canal":"WhatsApp","homolog":"Homologado","fuente":"OMNI_WA","proveedor":"OMNIEXPERIENCIA (Celeste MedPlus)","unidad":"Conversación 24h","fact":77493,"nofact":0,"registros":77493,"desde":"2026-09-01","hasta":"2026-09-28","mesTope":"Septiembre","tope":45000,"realMes":77493},{"key":"Bluecare_Agendamiento Inteligente_Chatbot [Cada respuesta]","cliente":"BlueCare","canal":"Chatbot","homolog":"Homologado","fuente":"TELECONSULTA_WA","proveedor":"ALOGLOBAL (Teleconsulta BlueCare)","unidad":"Respuesta bot","fact":38479,"nofact":0,"registros":38479,"desde":"2026-09-01","hasta":"2026-09-28","mesTope":"Septiembre","tope":25000,"realMes":38479},{"key":"Bluecare_Agendamiento Inteligente_Conversacion Whatsapp 24H Interaccion","cliente":"BlueCare","canal":"WhatsApp","homolog":"Homologado","fuente":"TELECONSULTA_WA","proveedor":"ALOGLOBAL (Teleconsulta BlueCare)","unidad":"Conversación 24h","fact":15918,"nofact":0,"registros":15918,"desde":"2026-09-01","hasta":"2026-09-28","mesTope":"Septiembre","tope":10000,"realMes":15918},{"key":"Bluecare_Encuestas de Satisfaccion Prestacion_Encuesta Email - SMS","cliente":"BlueCare","canal":"SMS + Email","homolog":"Por confirmar","fuente":"TOPPOINT","proveedor":"TOPPOINT","unidad":"SMS / Correo","fact":17809,"nofact":127,"registros":17936,"desde":"2026-09-01","hasta":"2026-09-29","mesTope":"Septiembre","tope":17560,"realMes":17809},{"key":"Medplus_Atención Canales de servicio al cliente_Email","cliente":"MedPlus","canal":"Email","homolog":"Homologado","fuente":"YESBPO_MAILING","proveedor":"YES BPO","unidad":"Correo","fact":286506,"nofact":0,"registros":12,"desde":"2026-09-07","hasta":"2026-09-16","mesTope":"Septiembre","tope":350000,"realMes":286506},{"key":"Bluecare_Proceso de novedades y apertura de agendas médicas_Mensajes de Texto","cliente":"BlueCare","canal":"SMS","homolog":"Homologado","fuente":"YESBPO_SMS","proveedor":"YES BPO","unidad":"SMS (segmento)","fact":755,"nofact":25,"registros":549,"desde":"2026-09-04","hasta":"2026-09-28","mesTope":"Septiembre","tope":1030,"realMes":755},{"key":"Medplus_Atención Canales de servicio al cliente_Mensajes de Texto","cliente":"MedPlus","canal":"SMS","homolog":"Homologado","fuente":"YESBPO_SMS","proveedor":"YES BPO","unidad":"SMS (segmento)","fact":115036,"nofact":3320,"registros":59178,"desde":"2026-09-08","hasta":"2026-09-16","mesTope":"Septiembre","tope":90000,"realMes":115036},{"key":"Medplus_Cobranza_Mensajes de Texto","cliente":"MedPlus","canal":"SMS","homolog":"Homologado","fuente":"YESBPO_SMS","proveedor":"YES BPO","unidad":"SMS (segmento)","fact":100406,"nofact":3508,"registros":51957,"desde":"2026-09-07","hasta":"2026-09-28","mesTope":"Septiembre","tope":125000,"realMes":100406}],"log":[{"FUENTE":"YESBPO_SMS","PASO":"Filas leídas","FILAS":111809,"DETALLE":"Resporte_Septiembre28_Yesbpo_SMS.xlsx"},{"FUENTE":"YESBPO_SMS","PASO":"Duplicados exactos eliminados","FILAS":125,"DETALLE":""},{"FUENTE":"YESBPO_SMS","PASO":"Envíos no facturables (errores)","FILAS":3430,"DETALLE":"Error de Repeticion: 3.113 · Error en formato: 293 · Ruta no permitida: 24"},{"FUENTE":"YESBPO_MAILING","PASO":"Filas leídas","FILAS":12,"DETALLE":"Yesbpo_Septiembre_Mailing.xlsx"},{"FUENTE":"YESBPO_MAILING","PASO":"Fechas escritas como texto convertidas","FILAS":1,"DETALLE":"\" 07/09/2026\""},{"FUENTE":"YESBPO_MAILING","PASO":"Fechas con año errado corregidas a 2026","FILAS":1,"DETALLE":"2029-09-08"},{"FUENTE":"YESBPO_MAILING","PASO":"Posible envío repetido (misma fecha y cantidad) – se conserva","FILAS":1,"DETALLE":"tickets 31900 y 31915 (2026-09-08, 21.927)"},{"FUENTE":"TOPPOINT","PASO":"Filas leídas (el .xls es texto tabulado)","FILAS":17936,"DETALLE":"SMS_MAILING_TOPPOIN.xls"},{"FUENTE":"TOPPOINT","PASO":"SMS \"EN COLA PARA ENVIO\" excluidos (son respuestas de encuesta)","FILAS":75,"DETALLE":""},{"FUENTE":"TOPPOINT","PASO":"Correos no enviados excluidos (EN COLA / NO DESEA RECIBIR)","FILAS":52,"DETALLE":""},{"FUENTE":"NUVETO_AVI","PASO":"Hoja Cartera_Sep: llamadas leídas","FILAS":11059,"DETALLE":"Nuveto_Septiembre.xlsx"},{"FUENTE":"NUVETO_AVI","PASO":"Hoja Cartera_Sep: duraciones inválidas (> 1 h o sin fin) no suman minutos","FILAS":12,"DETALLE":"sumaban 305.629 min; iniciadas 2026-08-27"},{"FUENTE":"NUVETO_AVI","PASO":"Hoja Laboratorio_Sep: llamadas leídas","FILAS":2011,"DETALLE":"Nuveto_Septiembre.xlsx"},{"FUENTE":"NUVETO_AVI","PASO":"Hoja Aseguramiento_Sep: llamadas leídas","FILAS":21634,"DETALLE":"Nuveto_Septiembre.xlsx"},{"FUENTE":"NUVETO_AVI","PASO":"Hoja Demanda_Inducida_sep: llamadas leídas","FILAS":1051,"DETALLE":"Nuveto_Septiembre.xlsx"},{"FUENTE":"NUVETO_AVI","PASO":"Hojas vacías (solo encabezado)","FILAS":2,"DETALLE":"Centros_Medicos_Sep · Asistenciales_Sep"},{"FUENTE":"TELECONSULTA_WA","PASO":"Filas leídas","FILAS":38479,"DETALLE":"teleconsulta.xlsx"},{"FUENTE":"TELECONSULTA_WA","PASO":"Fila TOTAL del reporte eliminada","FILAS":1,"DETALLE":""},{"FUENTE":"TELECONSULTA_WA","PASO":"Duplicados exactos eliminados","FILAS":0,"DETALLE":""},{"FUENTE":"TELECONSULTA_WA","PASO":"Filas de prueba u otro canal eliminadas (test_chat_bot)","FILAS":0,"DETALLE":""},{"FUENTE":"TELECONSULTA_WA","PASO":"Interacciones del bot","FILAS":38479,"DETALLE":""},{"FUENTE":"TELECONSULTA_WA","PASO":"Conversaciones de 24 h calculadas","FILAS":15918,"DETALLE":"celulares únicos: 9.996"},{"FUENTE":"OMNI_WA","PASO":"Filas leídas","FILAS":404340,"DETALLE":"omniexperienciacontact 1 a 15 septiembre.xls + omniexperienciacontact 16 al 28 septiembre.xls"},{"FUENTE":"OMNI_WA","PASO":"Fila TOTAL del reporte eliminada","FILAS":2,"DETALLE":""},{"FUENTE":"OMNI_WA","PASO":"Duplicados exactos eliminados","FILAS":266,"DETALLE":""},{"FUENTE":"OMNI_WA","PASO":"Filas de prueba u otro canal eliminadas (test_chat_bot)","FILAS":29,"DETALLE":""},{"FUENTE":"OMNI_WA","PASO":"Interacciones del bot","FILAS":404045,"DETALLE":""},{"FUENTE":"OMNI_WA","PASO":"Conversaciones de 24 h calculadas","FILAS":77493,"DETALLE":"celulares únicos: 35.663"}],"avisos":[{"nivel":"medio","texto":"Mailing: posible envío repetido en tickets 31900 y 31915 (2026-09-08, 21.927). Se dejó en el consumo."},{"nivel":"info","texto":"Search Key por confirmar · Toppoint: podría ser Clinica azul_Agendamiento de citas_Email; pendiente de confirmar."},{"nivel":"info","texto":"Search Key por confirmar · Toppoint: mapeo pendiente de confirmar con el coordinador."},{"nivel":"info","texto":"Search Key por confirmar · Nuveto: único Search Key de voicebot en el ppto; pendiente de confirmar."}],"totalFilas":498,"hojas":[{"hoja":"SMS_YesBPO","nombre":"Yes BPO · SMS","n":60,"desde":"2026-09-04","hasta":"2026-09-28","sin":0,"conf":0},{"hoja":"Mailing_YesBPO","nombre":"Yes BPO · Mailing","n":8,"desde":"2026-09-07","hasta":"2026-09-16","sin":0,"conf":0},{"hoja":"Toppoint","nombre":"Toppoint · SMS y Mailing","n":57,"desde":"2026-09-01","hasta":"2026-09-29","sin":0,"conf":57},{"hoja":"WA_Omniexperiencia","nombre":"Omniexperiencia · WhatsApp","n":56,"desde":"2026-09-01","hasta":"2026-09-28","sin":0,"conf":0},{"hoja":"WA_Teleconsulta","nombre":"Teleconsulta BlueCare · WhatsApp","n":56,"desde":"2026-09-01","hasta":"2026-09-28","sin":0,"conf":0},{"hoja":"AVI_Nuveto","nombre":"Nuveto · campañas AVI","n":261,"desde":"2026-08-27","hasta":"2026-09-28","sin":0,"conf":261}]};
  var OPCIONES = [['', 'Sin reconocer'], ['YESBPO_SMS', 'Yes BPO · SMS'], ['YESBPO_MAILING', 'Yes BPO · Mailing'], ['TOPPOINT', 'Toppoint · SMS y Mailing'],
    ['OMNI_WA', 'Omniexperiencia · WhatsApp'], ['TELECONSULTA_WA', 'Teleconsulta · WhatsApp'], ['NUVETO_AVI', 'Nuveto · campañas AVI'], ['PPTO', 'RealConsolidado · Search Keys del ppto']];

  var st = { files: [], filas: null, log: null, avisos: null, lote: null, ocupado: false, copiadas: {}, asign: {}, pend: [] };
  // Preferencias de este computador (si el navegador no deja guardar, la app sigue funcionando)
  function leerLS(k) { try { var v = localStorage.getItem(k); return v ? JSON.parse(v) : null; } catch (e) { return null; } }
  function guardarLS(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* sin almacenamiento */ } }
  (function () {
    var c = leerLS('consumos.catalogo');
    if (c && c.lineas && c.lineas.length) { try { E.setCatalogo(c); } catch (e) { /* catálogo dañado: se usa el incluido */ } }
    st.asign = leerLS('consumos.asignaciones') || {};
  })();
  var $ = function (id) { return document.getElementById(id); };
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function mb(n) { return n > 1048576 ? (n / 1048576).toFixed(1).replace('.', ',') + ' MB' : Math.max(1, Math.round(n / 1024)) + ' KB'; }
  function fechaCorta(s) { return s ? s.slice(8, 10) + '/' + s.slice(5, 7) : ''; }
  function tick() { return new Promise(function (r) { setTimeout(r, 16); }); }
  var NO_RECONOCIDO = 'No se reconoció: elija el formato o quítelo';

  // ----------------------------------------------------------- archivos
  function agregar(lista) {
    Array.prototype.forEach.call(lista, function (f) {
      if (st.files.some(function (x) { return x.file.name === f.name && x.file.size === f.size; })) return;
      var item = { id: Math.random().toString(36).slice(2), file: f, tipo: E.detectarPorNombre(f.name) || '', estado: 'listo', msg: '', prog: 0 };
      st.files.push(item);
      if (item.tipo === 'PPTO') cargarCatalogo(item);
      else if (!item.tipo) sniff(item);
    });
    pintarLista();
  }
  function sniff(item) {
    item.msg = 'Revisando contenido…'; pintarLista();
    item.file.slice(0, 4096).arrayBuffer().then(function (ab) {
      var u = new Uint8Array(ab);
      var zip = u[0] === 0x50 && u[1] === 0x4b;
      if (!zip) {
        item.tipo = E.detectarPorContenido(new TextDecoder('windows-1252').decode(u), false) || '';
        item.msg = item.tipo ? '' : NO_RECONOCIDO;
        pintarLista(); return;
      }
      if (item.file.size > 40 * 1048576) { item.msg = NO_RECONOCIDO; pintarLista(); return; }
      return item.file.arrayBuffer().then(function (buf) {
        try { item.tipo = E.detectarLibro(XLSX, new Uint8Array(buf)) || ''; } catch (e) { item.tipo = ''; }
        item.msg = item.tipo ? '' : NO_RECONOCIDO;
        if (item.tipo === 'PPTO') { cargarCatalogo(item); return; }
        pintarLista();
      });
    }).catch(function () { item.msg = 'No se pudo leer el archivo'; pintarLista(); });
  }
  // RealConsolidado2026: actualiza la lista de Search Keys (y topes Q Mes) desde pptoAjustado
  function cargarCatalogo(item) {
    item.msg = 'Leyendo pptoAjustado…'; pintarLista();
    item.file.arrayBuffer().then(function (buf) {
      var c = E.leerCatalogoPpto(XLSX, new Uint8Array(buf), item.file.name);
      E.setCatalogo(c); guardarLS('consumos.catalogo', c);
      item.estado = 'ok'; item.msg = 'Search Keys actualizados: ' + c.lineas.length + ' líneas de consumo';
      if (st.filas) { st.pend = E.rehomologar(st.filas, st.asign); pintarResultado(false); }
      pintarCatalogo(); pintarLista();
    }).catch(function (e) { item.estado = 'error'; item.msg = e && e.message ? e.message : 'No se pudo leer pptoAjustado'; pintarLista(); });
  }
  function pintarCatalogo() {
    var c = E.getCatalogo(), n = (c.lineas || []).length;
    var porCli = {};
    (c.lineas || []).forEach(function (l) { porCli[l.cliente] = (porCli[l.cliente] || 0) + 1; });
    $('cat-info').innerHTML = '<b>' + n + ' Search Keys de consumo</b> (' + Object.keys(porCli).map(function (k) { return esc(k) + ' ' + porCli[k]; }).join(' · ') + ')' +
      '<span class="muted"> · tomados de ' + esc(c.origen || 'pptoAjustado') + (c.fecha ? ', ' + esc(c.fecha.slice(8, 10) + '/' + c.fecha.slice(5, 7) + '/' + c.fecha.slice(0, 4)) : '') + '</span>';
    var na = Object.keys(st.asign).length;
    $('asig-info').innerHTML = na ? na + (na === 1 ? ' campaña asignada' : ' campañas asignadas') + ' a mano en este computador · <button class="link" id="btn-olvidar">Olvidar asignaciones</button>' : '';
  }
  $('asig-info').addEventListener('click', function (e) {
    if (e.target.id !== 'btn-olvidar') return;
    st.asign = {}; guardarLS('consumos.asignaciones', {});
    if (st.filas) { st.pend = E.rehomologar(st.filas, st.asign); pintarResultado(false); }
    pintarCatalogo();
  });

  function pintarLista() {
    var n = st.files.length;
    $('lista-wrap').hidden = n === 0;
    $('arch-count').textContent = n === 0 ? 'Ningún archivo cargado' : n + (n === 1 ? ' archivo' : ' archivos');
    $('btn-vaciar').disabled = n === 0 || st.ocupado;
    var procesables = st.files.filter(function (x) { return x.tipo && x.tipo !== 'PPTO'; }).length;
    $('btn-limpiar').disabled = procesables === 0 || st.ocupado || !window.XLSX;
    $('lista').innerHTML = st.files.map(function (x) {
      var opts = OPCIONES.map(function (o) { return '<option value="' + o[0] + '"' + (o[0] === x.tipo ? ' selected' : '') + '>' + o[1] + '</option>'; }).join('');
      var estado;
      if (x.estado === 'leyendo') estado = '<div class="bar" aria-label="Avance"><i style="width:' + Math.round(x.prog * 100) + '%"></i></div>';
      else if (x.estado === 'ok') estado = '<span class="status ok">' + esc(x.msg || 'Limpio') + '</span>';
      else if (x.estado === 'error') estado = '<span class="status bad">' + esc(x.msg) + '</span>';
      else estado = '<span class="status' + (x.tipo ? '' : ' warn') + '">' + esc(x.msg || (x.tipo ? 'Listo para limpiar' : NO_RECONOCIDO)) + '</span>';
      return '<tr><td class="fname">' + esc(x.file.name) + '</td><td class="num">' + mb(x.file.size) + '</td>' +
        '<td><select aria-label="Formato de ' + esc(x.file.name) + '" data-id="' + x.id + '"' + (st.ocupado ? ' disabled' : '') + '>' + opts + '</select></td>' +
        '<td>' + estado + '</td><td><button class="link" data-quitar="' + x.id + '"' + (st.ocupado ? ' disabled' : '') + '>Quitar</button></td></tr>';
    }).join('');
  }
  $('lista').addEventListener('change', function (e) {
    var id = e.target.getAttribute('data-id'); if (!id) return;
    var it = st.files.find(function (x) { return x.id === id; });
    it.tipo = e.target.value; it.msg = ''; it.estado = 'listo'; pintarLista();
  });
  $('lista').addEventListener('click', function (e) {
    var id = e.target.getAttribute('data-quitar'); if (!id) return;
    st.files = st.files.filter(function (x) { return x.id !== id; }); pintarLista();
  });
  $('btn-vaciar').addEventListener('click', function () { st.files = []; pintarLista(); });
  $('fi').addEventListener('change', function (e) { agregar(e.target.files); e.target.value = ''; });
  var drop = $('drop');
  ['dragenter', 'dragover'].forEach(function (ev) { drop.addEventListener(ev, function (e) { e.preventDefault(); drop.classList.add('over'); }); });
  ['dragleave', 'drop'].forEach(function (ev) { drop.addEventListener(ev, function (e) { e.preventDefault(); drop.classList.remove('over'); }); });
  drop.addEventListener('drop', function (e) { if (e.dataTransfer && e.dataTransfer.files) agregar(e.dataTransfer.files); });

  // ----------------------------------------------------------- limpieza
  async function leerHtml(ctx, item) {
    var lector = E.nuevoLectorHtml(ctx, item.tipo, item.file.name);
    var reader = item.file.stream().getReader();
    var dec = new TextDecoder('utf-8');
    var leidos = 0, n = 0;
    while (true) {
      var r = await reader.read();
      if (r.done) break;
      leidos += r.value.byteLength;
      lector.push(dec.decode(r.value, { stream: true }));
      if (++n % 24 === 0) { item.prog = leidos / item.file.size; pintarLista(); await tick(); }
    }
    lector.push(dec.decode()); lector.fin();
  }
  async function procesar(ctx, item) {
    var f = item.file;
    var cab = new Uint8Array(await f.slice(0, 4).arrayBuffer());
    var zip = cab[0] === 0x50 && cab[1] === 0x4b;
    if (item.tipo === 'OMNI_WA' || item.tipo === 'TELECONSULTA_WA') {
      if (zip) E.procesarCdrExcel(ctx, XLSX, new Uint8Array(await f.arrayBuffer()), f.name, item.tipo);
      else await leerHtml(ctx, item);
      return;
    }
    if (item.tipo === 'TOPPOINT') {
      if (zip) throw new Error('Este reporte de Toppoint viene como Excel real; la app espera el .xls de texto tabulado que envía el proveedor.');
      E.procesarToppoint(ctx, new TextDecoder('windows-1252').decode(new Uint8Array(await f.arrayBuffer())), f.name);
      return;
    }
    if (!zip) throw new Error('Se esperaba un archivo Excel (.xlsx).');
    var b = new Uint8Array(await f.arrayBuffer());
    if (item.tipo === 'YESBPO_SMS') E.procesarYesbpoSms(ctx, XLSX, b, f.name);
    else if (item.tipo === 'YESBPO_MAILING') E.procesarYesbpoMailing(ctx, XLSX, b, f.name);
    else if (item.tipo === 'NUVETO_AVI') E.procesarNuveto(ctx, XLSX, b, f.name);
  }
  $('btn-limpiar').addEventListener('click', async function () {
    if (st.ocupado) return;
    st.ocupado = true;
    var vent = Math.max(1, Math.min(168, parseInt($('vent').value, 10) || 24));
    var ctx = E.nuevoContexto({ ventanaHoras: vent });
    var cola = st.files.filter(function (x) { return x.tipo && x.tipo !== 'PPTO'; });
    cola.forEach(function (x) { x.estado = 'listo'; x.msg = 'En espera'; x.prog = 0; });
    $('st2').classList.add('on');
    var errores = 0;
    for (var i = 0; i < cola.length; i++) {
      var it = cola[i];
      it.estado = 'leyendo'; it.prog = 0.02; pintarLista();
      $('msg-proc').textContent = 'Limpiando ' + it.file.name + '… (' + (i + 1) + ' de ' + cola.length + ')';
      await tick(); await tick();
      try { await procesar(ctx, it); it.estado = 'ok'; it.msg = 'Limpio'; }
      catch (e) { it.estado = 'error'; it.msg = e && e.message ? e.message : 'No se pudo leer'; errores++; }
      pintarLista();
      await tick();
    }
    st.lote = E.lote(new Date());
    var filas = E.finalizar(ctx, st.lote, st.asign);
    st.filas = filas; st.log = ctx.log; st.avisos = ctx.avisos; st.copiadas = {}; st.pend = E.pendientes(filas);
    if (errores) st.avisos.unshift({ nivel: 'alto', texto: errores + (errores === 1 ? ' archivo no se pudo limpiar' : ' archivos no se pudieron limpiar') + '. Revise el mensaje en la lista de archivos; el resto sí quedó en el resultado.' });
    st.ocupado = false;
    $('msg-proc').textContent = filas.length ? 'Listo: ' + filas.length + ' filas limpias.' : 'No quedaron filas para pegar.';
    $('st2').classList.remove('on'); $('st2').classList.add('done'); $('st1').classList.remove('on'); $('st1').classList.add('done'); $('st3').classList.add('on');
    pintarLista();
    pintarResultado(false);
  });

  // ----------------------------------------------------------- resultado
  function pintarHojas(ejemplo) {
    var hojas = ejemplo ? EJEMPLO.hojas : E.porHoja(st.filas).map(function (h) {
      return { hoja: h.hoja, nombre: h.nombre, n: h.filas.length, desde: h.desde, hasta: h.hasta,
        sin: h.filas.filter(function (f) { return f.HOMOLOGACION === 'No homologado'; }).length,
        conf: h.filas.filter(function (f) { return f.HOMOLOGACION === 'Por confirmar'; }).length };
    });
    $('hojas').innerHTML = hojas.map(function (h) {
      var vacia = !h.n;
      var hecho = !ejemplo && st.copiadas[h.hoja];
      return '<div class="hoja' + (vacia ? ' vacia' : '') + (hecho ? ' hecha' : '') + '">' +
        '<div class="hoja-top"><span class="hoja-n mono">' + esc(h.hoja) + '</span>' + (hecho ? '<span class="chip ok">Copiada</span>' : '') + '</div>' +
        '<span class="hoja-f">' + esc(h.nombre) + '</span>' +
        '<span class="hoja-m mono">' + (vacia ? 'Sin archivo en esta carga' : E.fmt(h.n) + ' filas · ' + fechaCorta(h.desde) + ' – ' + fechaCorta(h.hasta)) + '</span>' +
        (h.sin ? '<span class="chip bad">' + h.sin + ' filas sin Search Key</span>' : (h.conf ? '<span class="chip warn">Search Key por confirmar</span>' : (vacia ? '' : '<span class="chip ok">Search Key en todas las filas</span>'))) +
        '<button data-hoja="' + esc(h.hoja) + '"' + (ejemplo || vacia ? ' disabled' : '') + '>Copiar filas</button></div>';
    }).join('');
  }
  function pintarResultado(ejemplo) {
    var filas = ejemplo ? EJEMPLO.filas : st.filas;
    var res = ejemplo ? EJEMPLO.resumen : E.resumen(filas);
    var log = ejemplo ? EJEMPLO.log : st.log;
    var avisos = ejemplo ? EJEMPLO.avisos : st.avisos;
    $('banner-ej').hidden = !ejemplo;
    $('res-chip').textContent = ejemplo ? 'Ejemplo: carga de septiembre (corte 28-sep)' : 'Lote ' + st.lote;
    $('res-chip').className = ejemplo ? 'chip plain' : 'chip ok';
    var desde = null, hasta = null, noFact = 0;
    res.forEach(function (r) { if (!desde || r.desde < desde) desde = r.desde; if (!hasta || r.hasta > hasta) hasta = r.hasta; noFact += r.nofact; });
    var formatos = {}; res.forEach(function (r) { formatos[r.fuente] = 1; });
    $('tiles').innerHTML = [
      ['Filas para pegar', E.fmt(ejemplo ? EJEMPLO.totalFilas : filas.length)],
      ['Formatos con datos', Object.keys(formatos).length + ' de ' + E.HOJAS.length],
      ['Líneas de consumo', res.length],
      ['Periodo', desde ? fechaCorta(desde) + ' – ' + fechaCorta(hasta) : '—'],
      ['Unidades no facturables', E.fmt(noFact)]
    ].map(function (t) { return '<div class="tile"><span class="k">' + t[0] + '</span><span class="v">' + t[1] + '</span></div>'; }).join('');
    $('avisos').innerHTML = (avisos || []).map(function (a) { return '<div class="aviso ' + (a.nivel === 'alto' ? 'alto' : a.nivel === 'info' ? 'info' : '') + '">' + esc(a.texto) + '</div>'; }).join('');
    pintarHojas(ejemplo);
    var ORD = { 'MedPlus': 1, 'BlueCare': 2, 'Clínica Azul': 3 };
    res.sort(function (a, b) { var x = (ORD[a.cliente] || 9) + a.canal + a.key, y = (ORD[b.cliente] || 9) + b.canal + b.key; return x < y ? -1 : 1; });
    var CH = { 'Homologado': 'ok', 'Homologado (manual)': 'ok', 'Por confirmar': 'warn', 'No homologado': 'bad' };
    $('resumen').innerHTML = res.map(function (r) {
      var pct = r.tope ? r.realMes / r.tope : null;
      return '<tr><td><span class="sk">' + esc(r.key) + '</span><div class="muted" style="font-size:12px">' + esc(r.cliente) + ' · ' + esc(r.proveedor) + ' · ' + esc(r.unidad) + '</div></td>' +
        '<td><span class="canal">' + esc(r.canal) + '</span></td>' +
        '<td><span class="chip ' + (CH[r.homolog] || 'plain') + '">' + esc(r.homolog || '') + '</span></td>' +
        '<td class="mono" style="white-space:nowrap">' + fechaCorta(r.desde) + ' – ' + fechaCorta(r.hasta) + '</td>' +
        '<td class="num">' + E.fmt(r.fact) + '</td><td class="num">' + (r.nofact ? E.fmt(r.nofact) : '—') + '</td>' +
        '<td class="num">' + (r.tope != null ? E.fmt(r.tope) : '—') + '<div class="muted" style="font-size:11px">' + esc(r.mesTope || '') + '</div></td>' +
        '<td class="num' + (r.homolog === 'Por confirmar' ? ' muted' : pct > 1 ? ' rojo' : pct >= 0.85 ? ' ambar' : '') + '">' + (pct != null ? Math.round(pct * 100) + '%' : '—') + '</td></tr>';
    }).join('');
    pintarPendientes(ejemplo);
    $('pre-h').innerHTML = '<tr><th>HOJA</th>' + E.COLUMNAS.map(function (c) { return '<th>' + c + '</th>'; }).join('') + '</tr>';
    $('pre-b').innerHTML = filas.slice(0, 25).map(function (f) { return '<tr><td>' + esc(f.HOJA) + '</td>' + E.COLUMNAS.map(function (c) { return '<td>' + esc(f[c]) + '</td>'; }).join('') + '</tr>'; }).join('');
    $('log').innerHTML = (log || []).map(function (l) { return '<tr><td>' + esc(l.FUENTE) + '</td><td>' + esc(l.PASO) + '</td><td class="num">' + E.fmt(l.FILAS) + '</td><td class="muted" style="font-size:12.5px">' + esc(l.DETALLE) + '</td></tr>'; }).join('');
    $('btn-excel').disabled = ejemplo || !filas.length;
    $('res-meta').textContent = ejemplo ? '' : 'Lote ' + st.lote + ' · ' + E.COLUMNAS.length + ' columnas por hoja';
    $('fallback').hidden = true; $('toast').textContent = '';
  }

  // Campañas nuevas: el usuario elige el Search Key (se recuerda en este computador)
  function pintarPendientes(ejemplo) {
    var p = ejemplo ? [] : (st.pend || []);
    $('pend').hidden = !p.length;
    $('pend-lista').innerHTML = p.map(function (x, i) {
      var sug = x.opciones.filter(function (o) { return o.sugerido; }), otros = x.opciones.filter(function (o) { return !o.sugerido; });
      var og = function (t, arr) { return arr.length ? '<optgroup label="' + esc(t) + '">' + arr.map(function (o) { return '<option value="' + esc(o.sk) + '">' + esc(o.sk) + '</option>'; }).join('') + '</optgroup>' : ''; };
      return '<div class="pend-fila"><div><b>' + esc(x.valor) + '</b><div class="muted" style="font-size:12.5px">' + esc(x.formato) + ' · ' + E.fmt(x.cantidad) + ' unidades facturables · ' + x.filas + ' filas</div></div>' +
        '<select data-pend="' + i + '" aria-label="Search Key para ' + esc(x.valor) + '"><option value="">Elegir Search Key…</option>' + og('Mismo canal', sug) + og('Otros canales', otros) + '</select>' +
        '<button data-asignar="' + i + '">Asignar</button></div>';
    }).join('');
  }
  $('pend-lista').addEventListener('click', function (e) {
    var i = e.target.getAttribute('data-asignar'); if (i == null) return;
    var sel = document.querySelector('select[data-pend="' + i + '"]'); if (!sel || !sel.value) { sel && sel.focus(); return; }
    var x = st.pend[+i];
    st.asign[x.clave] = sel.value; guardarLS('consumos.asignaciones', st.asign);
    st.pend = E.rehomologar(st.filas, st.asign);
    st.avisos = (st.avisos || []).filter(function (a) { return a.texto.indexOf('"' + x.valor + '"') < 0; });
    st.copiadas = {};
    pintarResultado(false); pintarCatalogo();
    $('toast').textContent = '"' + x.valor + '" quedó con el Search Key ' + sel.value + '. Vuelva a copiar la hoja de ese formato.';
  });

  $('hojas').addEventListener('click', function (e) {
    var b = e.target.closest ? e.target.closest('button[data-hoja]') : null;
    if (!b || b.disabled || !st.filas) return;
    var hoja = b.getAttribute('data-hoja');
    var filas = st.filas.filter(function (f) { return f.HOJA === hoja; });
    if (!filas.length) return;
    var tsv = E.aTsv(filas);
    var sinSK = filas.filter(function (f) { return f.HOMOLOGACION === 'No homologado'; }).length;
    function listo() {
      st.copiadas[hoja] = true;
      pintarHojas(false);
      $('fallback').hidden = true;
      $('toast').textContent = 'Copiadas ' + filas.length + ' filas de ' + hoja + '. Péguelas en la hoja ' + hoja + ', debajo de la última fila.' +
        (sinSK ? ' Ojo: ' + sinSK + ' filas van sin Search Key (asígnelo arriba y vuelva a copiar).' : '');
    }
    function fallback() {
      st.copiadas[hoja] = true; pintarHojas(false);
      $('fallback').hidden = false; var ta = $('ta'); ta.value = tsv; ta.focus(); ta.select();
      $('toast').textContent = 'Filas de ' + hoja + ' listas para copiar abajo.';
    }
    if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(tsv).then(listo, fallback);
    else fallback();
  });

  // ----------------------------------------------------------- Excel (una hoja por formato)
  function serial(ymdStr) {
    var y = +ymdStr.slice(0, 4), m = +ymdStr.slice(5, 7), d = +ymdStr.slice(8, 10);
    return (Date.UTC(y, m - 1, d) - Date.UTC(1899, 11, 30)) / 86400000;
  }
  function hojaExcel(filas) {
    var aoa = [E.COLUMNAS].concat(filas.map(function (f) { return E.COLUMNAS.map(function (c) { return f[c]; }); }));
    var ws = XLSX.utils.aoa_to_sheet(aoa);
    var cF = E.COLUMNAS.indexOf('FECHA'), cC = E.COLUMNAS.indexOf('FECHA_CORTE'), cL = E.COLUMNAS.indexOf('LOTE');
    for (var r = 1; r < aoa.length; r++) {
      [cF, cC].forEach(function (c) {
        var v = aoa[r][c];
        if (v) ws[XLSX.utils.encode_cell({ r: r, c: c })] = { t: 'n', v: serial(v), z: 'dd/mm/yyyy' };
      });
      var rl = XLSX.utils.encode_cell({ r: r, c: cL }); if (ws[rl]) ws[rl].z = '0';
    }
    ws['!cols'] = E.COLUMNAS.map(function (c) { return { wch: c === 'Search_Key' ? 62 : c === 'ARCHIVO' ? 40 : c === 'CAMPAÑA' || c === 'SERVICIO' || c === 'VALOR_ORIGEN' || c === 'CAMPAÑA_PROVEEDOR' ? 30 : c === 'HOMOLOGACION' ? 18 : 14 }; });
    return ws;
  }
  function libro() {
    var wb = XLSX.utils.book_new();
    E.porHoja(st.filas).forEach(function (h) { if (h.filas.length) XLSX.utils.book_append_sheet(wb, hojaExcel(h.filas), h.hoja); });
    var res = E.resumen(st.filas).map(function (r) { return { Search_Key: r.key, CLIENTE: r.cliente, CANAL: r.canal, HOMOLOGACION: r.homolog, PROVEEDOR: r.proveedor, DESDE: r.desde, HASTA: r.hasta, FACTURABLE: r.fact, NO_FACTURABLE: r.nofact, REGISTROS: r.registros, MES_TOPE: r.mesTope, TOPE_Q_MES: r.tope, REPORTADO_MES: r.realMes }; });
    XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(res), 'Resumen');
    XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(st.log), 'Log_limpieza');
    return XLSX.write(wb, { type: 'array', bookType: 'xlsx' });
  }
  $('btn-excel').addEventListener('click', function () {
    if (!st.filas || !st.filas.length) return;
    try {
      var blob = new Blob([libro()], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
      var url = URL.createObjectURL(blob);
      var a = document.createElement('a');
      a.href = url; a.download = 'Consumos_lote_' + st.lote + '.xlsx';
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(function () { URL.revokeObjectURL(url); }, 4000);
      $('toast').textContent = 'Excel descargado: trae una hoja por formato con el mismo nombre de la hoja donde se pega.';
    } catch (e) { $('toast').textContent = 'No se pudo crear el Excel: ' + (e && e.message ? e.message : e) + '. Use los botones Copiar filas.'; }
  });

  pintarLista();
  pintarCatalogo();
  pintarResultado(true);
  if (!window.XLSX) $('msg-proc').textContent = 'No cargó el lector de Excel (carpeta lib). Descomprima el ZIP completo y vuelva a abrir.';
})();
