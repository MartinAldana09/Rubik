/* Motor de limpieza de consumos (SMS · Mailing · WhatsApp). Funciona igual en navegador y en Node. */
(function (root) {
  'use strict';
  var MESES = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'];

  var TIPOS = {
    YESBPO_SMS: { nombre: 'Yes BPO · SMS', canal: 'SMS', proveedor: 'YES BPO' },
    YESBPO_MAILING: { nombre: 'Yes BPO · Mailing', canal: 'MAILING', proveedor: 'YES BPO' },
    TOPPOINT: { nombre: 'Toppoint · SMS y Mailing', canal: 'SMS / MAILING', proveedor: 'TOPPOINT' },
    OMNI_WA: { nombre: 'Omniexperiencia · WhatsApp', canal: 'WHATSAPP', proveedor: 'OMNIEXPERIENCIA (Celeste MedPlus)' },
    TELECONSULTA_WA: { nombre: 'Teleconsulta BlueCare · WhatsApp', canal: 'WHATSAPP', proveedor: 'ALOGLOBAL (Teleconsulta BlueCare)' },
    NUVETO_AVI: { nombre: 'Nuveto · campañas AVI', canal: 'AVI GESTIÓN', proveedor: 'NUVETO' }
  };

  // Hoja de destino (una por formato) y orden en que se muestran
  var HOJAS = [
    { fuente: 'YESBPO_SMS', hoja: 'SMS_YesBPO' },
    { fuente: 'YESBPO_MAILING', hoja: 'Mailing_YesBPO' },
    { fuente: 'TOPPOINT', hoja: 'Toppoint' },
    { fuente: 'OMNI_WA', hoja: 'WA_Omniexperiencia' },
    { fuente: 'TELECONSULTA_WA', hoja: 'WA_Teleconsulta' },
    { fuente: 'NUVETO_AVI', hoja: 'AVI_Nuveto' }
  ];
  function hojaDe(fuente) { for (var i = 0; i < HOJAS.length; i++) if (HOJAS[i].fuente === fuente) return HOJAS[i].hoja; return fuente; }

  // ------------------------------------------------------------ Search Key (texto exacto del pptoAjustado)
  // Cada campaña del proveedor -> Search Key del ppto. h = estado de la homologación.
  var MAPEO_BASE = {
    'YESBPO_SMS|tickets': { sk: 'Medplus_Atención Canales de servicio al cliente_Mensajes de Texto', h: 'Homologado', sub: 'SMS', unidad: 'SMS (segmento)' },
    'YESBPO_SMS|cartera': { sk: 'Medplus_Cobranza_Mensajes de Texto', h: 'Homologado', sub: 'SMS', unidad: 'SMS (segmento)' },
    'YESBPO_SMS|novedades': { sk: 'Bluecare_Proceso de novedades y apertura de agendas médicas_Mensajes de Texto', h: 'Homologado', sub: 'SMS', unidad: 'SMS (segmento)' },
    'YESBPO_MAILING|medplus_atención canales de servicio al cliente': { sk: 'Medplus_Atención Canales de servicio al cliente_Email', h: 'Homologado', sub: 'Email', unidad: 'Correo' },
    'TOPPOINT|sms_centros medicos': { sk: 'Bluecare_Encuestas de Satisfaccion Prestacion_Encuesta Email - SMS', h: 'Por confirmar', sub: 'SMS', unidad: 'SMS',
      nota: 'Toppoint: mapeo pendiente de confirmar con el coordinador.' },
    'TOPPOINT|clinica azul_mailing': { sk: 'Bluecare_Encuestas de Satisfaccion Prestacion_Encuesta Email - SMS', h: 'Por confirmar', sub: 'Email', unidad: 'Correo',
      nota: 'Toppoint: podría ser Clinica azul_Agendamiento de citas_Email; pendiente de confirmar.' },
    'OMNI_WA|conversaciones': { sk: 'Medplus_Asistente Virtual_Conversacion Whatsapp 24H Interaccion', h: 'Homologado', sub: 'WhatsApp', unidad: 'Conversación 24h' },
    'OMNI_WA|interacciones': { sk: 'Medplus_Asistente Virtual_Chatbot [Cada respuesta]', h: 'Homologado', sub: 'WhatsApp', unidad: 'Respuesta bot' },
    'TELECONSULTA_WA|conversaciones': { sk: 'Bluecare_Agendamiento Inteligente_Conversacion Whatsapp 24H Interaccion', h: 'Homologado', sub: 'WhatsApp', unidad: 'Conversación 24h' },
    'TELECONSULTA_WA|interacciones': { sk: 'Bluecare_Agendamiento Inteligente_Chatbot [Cada respuesta]', h: 'Homologado', sub: 'WhatsApp', unidad: 'Respuesta bot' },
    'NUVETO_AVI|*': { sk: 'Medplus_Atención Canales de servicio al cliente_VoiceBot_Campañas', h: 'Por confirmar', sub: 'Llamada', unidad: 'Minuto',
      nota: 'Nuveto: único Search Key de voicebot en el ppto; pendiente de confirmar.' }
  };
  // Canal esperado de cada formato (para proponer Search Keys a campañas nuevas)
  var CANAL_FUENTE = { YESBPO_SMS: 'SMS', YESBPO_MAILING: 'Email', TOPPOINT: 'SMS + Email', OMNI_WA: 'WhatsApp', TELECONSULTA_WA: 'WhatsApp', NUVETO_AVI: 'Voicebot (AVI)' };
  var CLIENTES = { 'medplus': 'MedPlus', 'bluecare': 'BlueCare', 'clinica azul': 'Clínica Azul', 'cienogroup': 'CienoGroup', 'tu boleta': 'Tu Boleta', 'nuevos negocios': 'Nuevos Negocios', 'fundacion': 'Fundación' };

  // Clave normalizada (igual que en Power Query): minúsculas, sin tildes, sin espacios sobrantes ni alrededor de "_"
  function clave(s) {
    if (s == null) return '';
    var t = String(s).normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();
    return t.replace(/\s+/g, ' ').trim().replace(/\s*_\s*/g, '_');
  }
  function partesSK(sk) {
    var p = String(sk).trim().split('_');
    return { cliente: (p[0] || '').trim(), campana: (p[1] || '').trim(), servicio: p.slice(2).join('_').trim() };
  }
  function nombreCliente(c) { var k = clave(c); return CLIENTES[k] || String(c || '').trim(); }
  // Canal a partir del servicio (DETALLE DEL GASTO): misma regla que el tablero
  function canalDe(servicio) {
    var c = clave(servicio);
    if (c.indexOf('bolsa') >= 0) return null;
    if (c.indexOf('encuesta email - sms') >= 0 || c.indexOf('encuesta email-sms') >= 0) return 'SMS + Email';
    if (c.indexOf('mensajes de texto') >= 0 || c.indexOf('mensaje de texto') >= 0 || /\bsms\b/.test(c)) return 'SMS';
    if (c.indexOf('e-mail') >= 0 || /\bemail\b/.test(c) || c.indexOf('correo') >= 0 || c.indexOf('mailing') >= 0) return 'Email';
    if (c.indexOf('chatbot') >= 0) return 'Chatbot';
    if (c.indexOf('conversacion whatsapp') >= 0 || ((c.indexOf('whatsapp') >= 0 || c.indexOf('whatsaap') >= 0) && c.indexOf('mensaje') >= 0)) return 'WhatsApp';
    if (c.indexOf('voicebot') >= 0 || c.indexOf('voice bot') >= 0) return 'Voicebot (AVI)';
    if (/\bbot\b/.test(c)) return 'Bot de agenda';
    return null; // telefonía, puestos, licencias, etc.: fuera del alcance de consumos
  }

  var MAPEO = {};
  Object.keys(MAPEO_BASE).forEach(function (k) { var i = k.indexOf('|'); MAPEO[k.slice(0, i) + '|' + clave(k.slice(i + 1))] = MAPEO_BASE[k]; });

  // Catálogo de Search Keys de consumo del pptoAjustado (se puede reemplazar cargando RealConsolidado2026)
  var CATALOGO_DEF = (typeof root !== 'undefined' && root.ConsumosCatalogo) || (typeof require === 'function' ? require('./catalogo.js') : { lineas: [] });
  var catalogo = null, catIdx = {};
  function setCatalogo(c) {
    catalogo = c; catIdx = {};
    (c.lineas || []).forEach(function (l) { catIdx[clave(l.sk)] = l; });
  }
  setCatalogo(CATALOGO_DEF);
  function getCatalogo() { return catalogo; }
  function buscarSK(sk) { return catIdx[clave(sk)] || null; }

  // Lee pptoAjustado de RealConsolidado2026 y arma el catálogo de Search Keys de consumo (con Q de cada mes)
  function leerCatalogoPpto(XLSX, buf, nombreArchivo) {
    var wb = XLSX.read(buf, { type: 'array' });
    var hoja = wb.SheetNames.filter(function (n) { return n.trim().toLowerCase() === 'pptoajustado'; })[0];
    if (!hoja) throw new Error('El archivo no tiene la hoja pptoAjustado.');
    var ws = wb.Sheets[hoja]; fijarRango(XLSX, ws);
    var aoa = XLSX.utils.sheet_to_json(ws, { header: 1, raw: true, defval: null, blankrows: false });
    var h = (aoa[0] || []).map(function (x) { return clave(x); });
    var iSK = h.indexOf('search_key'), iCli = h.indexOf('cliente');
    var iQ = MESES.map(function (m) { return h.indexOf(clave('Q ' + m)); });
    if (iSK < 0 || iQ.some(function (i) { return i < 0; })) throw new Error('En pptoAjustado no encontré Search_Key o alguna columna "Q Mes".');
    var lineas = [], vistos = {};
    for (var r = 1; r < aoa.length; r++) {
      var row = aoa[r]; if (!row || row[iSK] == null) continue;
      var sk = String(row[iSK]).trim(); if (!sk || vistos[clave(sk)]) continue;
      var pt = partesSK(sk), can = canalDe(pt.servicio);
      if (!can) continue;
      vistos[clave(sk)] = 1;
      lineas.push({ sk: sk, cliente: nombreCliente(iCli >= 0 ? row[iCli] : pt.cliente), campana: pt.campana, servicio: pt.servicio, canal: can,
        q: iQ.map(function (i) { var v = row[i]; return typeof v === 'number' ? v : (v == null || v === '' ? null : Number(String(v).replace(/\./g, '').replace(',', '.'))); }) });
    }
    if (!lineas.length) throw new Error('pptoAjustado no trae líneas de consumo (SMS, Email, WhatsApp, Chatbot, Voicebot o Bot).');
    var hoy = new Date();
    return { origen: (nombreArchivo || 'RealConsolidado2026') + ' · pptoAjustado', fecha: ymd(hoy.getFullYear(), hoy.getMonth() + 1, hoy.getDate()), lineas: lineas };
  }

  var COLUMNAS = ['FECHA', 'AÑO', 'NRO_MES', 'MES', 'CLIENTE', 'Search_Key', 'CAMPAÑA', 'SERVICIO', 'CANAL', 'SUBCANAL', 'PROVEEDOR', 'FUENTE',
    'ARCHIVO', 'CAMPAÑA_PROVEEDOR', 'VALOR_ORIGEN', 'ESTADO', 'ES_FACTURABLE', 'UNIDAD', 'CANTIDAD', 'REGISTROS', 'FECHA_CORTE', 'LOTE', 'HOMOLOGACION'];

  // ------------------------------------------------------------ utilidades
  function cyrb53(str) {
    var h1 = 0xdeadbeef, h2 = 0x41c6ce57;
    for (var i = 0, ch; i < str.length; i++) {
      ch = str.charCodeAt(i);
      h1 = Math.imul(h1 ^ ch, 2654435761);
      h2 = Math.imul(h2 ^ ch, 1597334677);
    }
    h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
    h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
    return 4294967296 * (2097151 & h2) + (h1 >>> 0);
  }
  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function ymd(y, m, d) { return y + '-' + pad(m) + '-' + pad(d); }
  function validYmd(y, m, d) { return y > 1990 && y < 2200 && m >= 1 && m <= 12 && d >= 1 && d <= 31; }
  function norm(s) { return s == null ? '' : String(s).trim(); }
  function low(s) { return norm(s).toLowerCase(); }

  // Convierte cualquier valor de fecha a 'AAAA-MM-DD' (o null). Devuelve también si vino como texto dd/mm/aaaa.
  function aFecha(v, XLSX) {
    if (v == null || v === '') return null;
    if (typeof v === 'number') {
      var p = XLSX.SSF.parse_date_code(v);
      return p && validYmd(p.y, p.m, p.d) ? ymd(p.y, p.m, p.d) : null;
    }
    if (v instanceof Date) return ymd(v.getFullYear(), v.getMonth() + 1, v.getDate());
    var t = String(v).trim();
    var m = /^(\d{4})-(\d{1,2})-(\d{1,2})/.exec(t);
    if (m && validYmd(+m[1], +m[2], +m[3])) return ymd(+m[1], +m[2], +m[3]);
    m = /^(\d{1,2})\/(\d{1,2})\/(\d{4})/.exec(t);
    if (m && validYmd(+m[3], +m[2], +m[1])) return ymd(+m[3], +m[2], +m[1]);
    return null;
  }
  // 'AAAA-MM-DD HH:MM:SS' -> ms (hora local "ingenua", solo para diferencias)
  function aMs(t) {
    var m = /^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2}):(\d{2})/.exec(t);
    if (!m) return null;
    return Date.UTC(+m[1], +m[2] - 1, +m[3], +m[4], +m[5], +m[6]);
  }
  function msAFecha(ms) { var d = new Date(ms); return ymd(d.getUTCFullYear(), d.getUTCMonth() + 1, d.getUTCDate()); }
  function fmt(n) { return Math.round(n).toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.'); }

  // ------------------------------------------------------------ detección
  function detectarPorNombre(nombre) {
    var n = nombre.toLowerCase();
    if (n.indexOf('nuveto') >= 0) return 'NUVETO_AVI';
    if (n.indexOf('yesbpo') >= 0 && n.indexOf('sms') >= 0) return 'YESBPO_SMS';
    if (n.indexOf('yesbpo') >= 0 && n.indexOf('mail') >= 0) return 'YESBPO_MAILING';
    if (n.indexOf('toppoin') >= 0) return 'TOPPOINT';
    if (n.indexOf('omniexperiencia') >= 0) return 'OMNI_WA';
    if (n.indexOf('teleconsulta') >= 0) return 'TELECONSULTA_WA';
    if (n.indexOf('realconsolidado') >= 0) return 'PPTO';
    return null;
  }
  // Mira los primeros bytes (como texto) cuando el nombre no dice nada
  function detectarPorContenido(inicioTexto, esZip) {
    var t = inicioTexto || '';
    if (!esZip) {
      if (/<html/i.test(t) && /SESSION_ID/.test(t)) {
        if (/teleconsulta/i.test(t)) return 'TELECONSULTA_WA';
        return 'OMNI_WA';
      }
      if (/^Id Correo\t/.test(t)) return 'TOPPOINT';
    }
    return null;
  }
  function detectarLibro(XLSX, buf) {
    var wb = XLSX.read(buf, { type: 'array', sheetRows: 12 });
    if (wb.SheetNames.some(function (n) { return n.trim().toLowerCase() === 'pptoajustado'; })) return 'PPTO';
    var ws = wb.Sheets[wb.SheetNames[0]];
    fijarRango(XLSX, ws);
    var aoa = XLSX.utils.sheet_to_json(ws, { header: 1, raw: true, defval: null });
    var plano = JSON.stringify(aoa).toLowerCase();
    if (plano.indexOf('fecha de inicio') >= 0 && plano.indexOf('fecha final') >= 0) return 'NUVETO_AVI';
    if (plano.indexOf('id de env') >= 0 && plano.indexOf('mero de mensajes') >= 0) return 'YESBPO_SMS';
    if (plano.indexOf('"cantidades"') >= 0 && plano.indexOf('"ticket"') >= 0) return 'YESBPO_MAILING';
    if (plano.indexOf('session_id') >= 0) return plano.indexOf('teleconsulta') >= 0 ? 'TELECONSULTA_WA' : 'OMNI_WA';
    return null;
  }

  // Algunos reportes (Yes BPO) traen mal la dimensión de la hoja: se recalcula con las celdas reales
  function fijarRango(XLSX, ws) {
    var maxR = 0, maxC = 0, any = false;
    for (var k in ws) {
      if (k.charAt(0) === '!') continue;
      var c = XLSX.utils.decode_cell(k);
      if (c.r > maxR) maxR = c.r;
      if (c.c > maxC) maxC = c.c;
      any = true;
    }
    if (any) ws['!ref'] = XLSX.utils.encode_range({ s: { r: 0, c: 0 }, e: { r: maxR, c: maxC } });
  }
  function leerHoja(XLSX, buf) {
    var wb = XLSX.read(buf, { type: 'array', cellDates: false, dense: false });
    var ws = wb.Sheets[wb.SheetNames[0]];
    fijarRango(XLSX, ws);
    return XLSX.utils.sheet_to_json(ws, { header: 1, raw: true, defval: null, blankrows: false });
  }

  // ------------------------------------------------------------ contexto de una corrida
  function nuevoContexto(opciones) {
    return {
      ventanaHoras: (opciones && opciones.ventanaHoras) || 24,
      anioActual: (opciones && opciones.anioActual) || new Date().getFullYear(),
      grupos: {},          // agregados de SMS / Mailing / Toppoint
      cdr: {},             // acumuladores WhatsApp por fuente
      log: [],
      avisos: [],
      archivos: []
    };
  }
  function log(ctx, fuente, paso, filas, detalle) { ctx.log.push({ FUENTE: fuente, PASO: paso, FILAS: filas, DETALLE: detalle || '' }); }
  function aviso(ctx, nivel, texto) { ctx.avisos.push({ nivel: nivel, texto: texto }); }
  function sumar(ctx, fuente, archivo, fecha, campana, estado, fact, cantidad, registros) {
    var k = [fuente, archivo, fecha, campana, estado, fact].join('\u0001');
    var g = ctx.grupos[k];
    if (!g) g = ctx.grupos[k] = { FUENTE: fuente, ARCHIVO: archivo, FECHA: fecha, CAMPAÑA: campana, VALOR_ORIGEN: campana, ESTADO: estado, ES_FACTURABLE: fact, CANTIDAD: 0, REGISTROS: 0 };
    g.CANTIDAD += cantidad; g.REGISTROS += registros;
  }
  function indices(encabezado, nombres) {
    var h = encabezado.map(function (x) { return low(x); });
    var r = {};
    nombres.forEach(function (n) { r[n] = h.indexOf(n.toLowerCase()); });
    return r;
  }
  function faltantes(idx) { return Object.keys(idx).filter(function (k) { return idx[k] < 0; }); }

  // ------------------------------------------------------------ 1. Yes BPO SMS
  function procesarYesbpoSms(ctx, XLSX, buf, archivo) {
    var F = 'YESBPO_SMS';
    var aoa = leerHoja(XLSX, buf);
    var idx = indices(aoa[0] || [], ['id de envío', 'fecha envío', 'estado', 'número de mensajes', 'nombre de campaña']);
    var f = faltantes(idx);
    if (f.length) throw new Error('No encontré las columnas: ' + f.join(', ') + '. ¿Es el reporte de SMS de Yes BPO?');
    var vistos = new Set(), dup = 0, sinFecha = 0, noFact = 0, errores = {}, n = 0;
    for (var i = 1; i < aoa.length; i++) {
      var r = aoa[i]; if (!r) continue;
      n++;
      var h = cyrb53(JSON.stringify(r));
      if (vistos.has(h)) { dup++; continue; }
      vistos.add(h);
      var fecha = aFecha(r[idx['fecha envío']], XLSX);
      if (!fecha) { sinFecha++; continue; }
      var estado = norm(r[idx['estado']]);
      var fact = estado === 'Entregado a la red' ? 1 : 0;
      if (!fact) { noFact++; errores[estado] = (errores[estado] || 0) + 1; }
      var seg = Number(r[idx['número de mensajes']]) || 0;
      var camp = norm(r[idx['nombre de campaña']]) || '(sin campaña)';
      sumar(ctx, F, archivo, fecha, camp, estado, fact, seg, 1);
    }
    log(ctx, F, 'Filas leídas', n, archivo);
    log(ctx, F, 'Duplicados exactos eliminados', dup);
    if (sinFecha) log(ctx, F, 'Filas sin fecha de envío (descartadas)', sinFecha);
    log(ctx, F, 'Envíos no facturables (errores)', noFact, Object.keys(errores).map(function (k) { return k + ': ' + fmt(errores[k]); }).join(' · '));
  }

  // ------------------------------------------------------------ 2. Yes BPO Mailing
  function procesarYesbpoMailing(ctx, XLSX, buf, archivo) {
    var F = 'YESBPO_MAILING';
    var aoa = leerHoja(XLSX, buf);
    var idx = indices(aoa[0] || [], ['Campaña', 'Ticket', 'Envio', 'Cantidades']);
    var f = faltantes(idx);
    if (f.length) throw new Error('No encontré las columnas: ' + f.join(', ') + '. ¿Es el reporte de Mailing de Yes BPO?');
    var textos = [], anios = [], n = 0, vistos = {}, repetidos = [];
    for (var i = 1; i < aoa.length; i++) {
      var r = aoa[i]; if (!r || r[idx['Campaña']] == null || r[idx['Cantidades']] == null) continue;
      n++;
      var v = r[idx['Envio']];
      var fecha = aFecha(v, XLSX);
      if (typeof v === 'string' && fecha) textos.push('"' + v + '"');
      if (!fecha) { aviso(ctx, 'alto', 'Mailing: la fila con ticket ' + norm(r[idx['Ticket']]) + ' no tiene una fecha legible (' + v + ') y se descartó.'); continue; }
      var y = +fecha.slice(0, 4);
      if (y > ctx.anioActual) { anios.push(fecha); fecha = ctx.anioActual + fecha.slice(4); }
      var camp = norm(r[idx['Campaña']]);
      var p = camp.lastIndexOf('_');
      var base = p > 0 ? camp.slice(0, p) : camp;
      var cant = Number(r[idx['Cantidades']]) || 0;
      var llave = fecha + '|' + cant;
      if (vistos[llave]) repetidos.push('tickets ' + vistos[llave] + ' y ' + norm(r[idx['Ticket']]) + ' (' + fecha + ', ' + fmt(cant) + ')');
      else vistos[llave] = norm(r[idx['Ticket']]);
      sumar(ctx, F, archivo, fecha, base, 'Enviado', 1, cant, 1);
    }
    log(ctx, F, 'Filas leídas', n, archivo);
    if (textos.length) log(ctx, F, 'Fechas escritas como texto convertidas', textos.length, textos.join(' · '));
    if (anios.length) log(ctx, F, 'Fechas con año errado corregidas a ' + ctx.anioActual, anios.length, anios.join(' · '));
    if (repetidos.length) {
      log(ctx, F, 'Posible envío repetido (misma fecha y cantidad) – se conserva', repetidos.length, repetidos.join(' · '));
      aviso(ctx, 'medio', 'Mailing: posible envío repetido en ' + repetidos.join('; ') + '. Se dejó en el consumo.');
    }
  }

  // ------------------------------------------------------------ 3. Toppoint (texto tabulado)
  function procesarToppoint(ctx, texto, archivo) {
    var F = 'TOPPOINT';
    var lineas = texto.split(/\r?\n/);
    var enc = lineas[0].split('\t');
    var idx = indices(enc, ['Id Correo', 'Estado', 'Hora Envio', 'Fecha', 'Proceso']);
    var f = faltantes(idx);
    if (f.length) throw new Error('No encontré las columnas: ' + f.join(', ') + '. ¿Es el reporte SMS/Mailing de Toppoint?');
    var n = 0, colaSms = 0, noEnv = 0, sinFecha = 0;
    for (var i = 1; i < lineas.length; i++) {
      if (!lineas[i]) continue;
      var c = lineas[i].split('\t');
      var proceso = norm(c[idx['Proceso']]);
      if (!proceso) continue;
      n++;
      var hora = norm(c[idx['Hora Envio']]);
      var fecha = hora ? aFecha(hora.slice(0, 10)) : aFecha(norm(c[idx['Fecha']]));
      if (!fecha) { sinFecha++; continue; }
      var estadoRaw = norm(c[idx['Estado']]).toUpperCase();
      var esSms = proceso.toUpperCase().indexOf('SMS') === 0;
      var estado = esSms && estadoRaw === 'PENDIENTE' ? 'Enviado (SMS)'
        : estadoRaw.toLowerCase().replace(/(^|\s)\S/g, function (s) { return s.toUpperCase(); });
      var fact = (estadoRaw === 'EN COLA PARA ENVIO' || estadoRaw === 'NO DESEA RECIBIR CORREOS') ? 0 : 1;
      if (!fact) { if (esSms) colaSms++; else noEnv++; }
      sumar(ctx, F, archivo, fecha, proceso, estado, fact, 1, 1);
    }
    log(ctx, F, 'Filas leídas (el .xls es texto tabulado)', n, archivo);
    log(ctx, F, 'SMS "EN COLA PARA ENVIO" excluidos (son respuestas de encuesta)', colaSms);
    log(ctx, F, 'Correos no enviados excluidos (EN COLA / NO DESEA RECIBIR)', noEnv);
    if (sinFecha) log(ctx, F, 'Filas sin fecha (descartadas)', sinFecha);
  }

  // ------------------------------------------------------------ 3-B. Nuveto (una hoja por campaña)
  var MES_SUFIJO = /_(ene|feb|mar|abr|may|jun|jul|ago|sep|sept|set|oct|nov|dic)[a-z]*$/i;
  function nombreCampana(hoja) { return norm(hoja).replace(MES_SUFIJO, '').replace(/_/g, ' ').trim(); }
  function aSerial(v) {
    if (v == null || v === '') return null;
    if (typeof v === 'number') return v;
    var ms = aMs(String(v).trim());
    return ms == null ? null : ms / 86400000 + 25569;  // días desde 1899-12-30
  }
  function procesarNuveto(ctx, XLSX, buf, archivo) {
    var F = 'NUVETO_AVI';
    var wb = XLSX.read(buf, { type: 'array', cellDates: false });
    var hojas = 0, sinFila = [];
    wb.SheetNames.forEach(function (nombre) {
      var ws = wb.Sheets[nombre];
      fijarRango(XLSX, ws);
      var aoa = XLSX.utils.sheet_to_json(ws, { header: 1, raw: true, defval: null, blankrows: false });
      if (!aoa.length) return;
      var enc = aoa[0].map(low);
      var iIni = enc.indexOf('fecha de inicio'), iFin = enc.indexOf('fecha final');
      if (iIni < 0 || iFin < 0) { aviso(ctx, 'medio', 'Nuveto: la hoja "' + nombre + '" no tiene Fecha de inicio / Fecha final y se omitió.'); return; }
      var iGes = -1;
      ['gestion llamada', 'gestion', 'tipificacion'].some(function (c) { iGes = enc.indexOf(c); return iGes >= 0; });
      var camp = nombreCampana(nombre);
      hojas++;
      if (aoa.length < 2) { sinFila.push(nombre); return; }
      var vistos = new Set(), n = 0, dup = 0, inval = 0, minInval = 0, sinIni = 0, fechasInval = {};
      for (var r = 1; r < aoa.length; r++) {
        var row = aoa[r]; if (!row) continue;
        n++;
        var h = cyrb53(JSON.stringify(row));
        if (vistos.has(h)) { dup++; continue; }
        vistos.add(h);
        var ini = aSerial(row[iIni]), fin = aSerial(row[iFin]);
        if (ini == null) { sinIni++; continue; }
        var p = XLSX.SSF.parse_date_code(ini);
        var fecha = ymd(p.y, p.m, p.d);
        var seg = fin == null ? NaN : Math.round((fin - ini) * 86400);
        var ok = seg > 0 && seg <= 3600;
        if (!ok) { inval++; if (!isNaN(seg)) minInval += seg / 60; fechasInval[fecha] = 1; }
        var g = iGes >= 0 ? norm(row[iGes]) : '';
        var estado = (!g || g === 'N/A') ? 'Sin gestión' : g.replace('Tipificación: ', '');
        var k = [F, archivo, fecha, camp, estado, ok ? 1 : 0].join('\u0001');
        var gr = ctx.grupos[k];
        if (!gr) gr = ctx.grupos[k] = { FUENTE: F, ARCHIVO: archivo, FECHA: fecha, CAMPAÑA: camp, VALOR_ORIGEN: '*', ESTADO: estado, ES_FACTURABLE: ok ? 1 : 0, CANTIDAD: 0, REGISTROS: 0, _seg: 0 };
        if (ok) gr._seg += seg;
        gr.REGISTROS += 1;
      }
      log(ctx, F, 'Hoja ' + nombre + ': llamadas leídas', n, archivo);
      if (dup) log(ctx, F, 'Hoja ' + nombre + ': duplicados exactos eliminados', dup);
      if (sinIni) log(ctx, F, 'Hoja ' + nombre + ': filas sin fecha de inicio (descartadas)', sinIni);
      if (inval) log(ctx, F, 'Hoja ' + nombre + ': duraciones inválidas (> 1 h o sin fin) no suman minutos', inval,
        'sumaban ' + fmt(minInval) + ' min; iniciadas ' + Object.keys(fechasInval).sort().join(', '));
    });
    if (sinFila.length) log(ctx, F, 'Hojas vacías (solo encabezado)', sinFila.length, sinFila.join(' · '));
    if (!hojas) throw new Error('No encontré hojas con Fecha de inicio / Fecha final. ¿Es el reporte de campañas de Nuveto?');
  }

  // ------------------------------------------------------------ 4. WhatsApp (CDR)
  function acumCdr(ctx, fuente) {
    var a = ctx.cdr[fuente];
    if (!a) a = ctx.cdr[fuente] = { vistos: new Set(), porCel: new Map(), inter: {}, archivoDia: {}, leidas: 0, total: 0, dup: 0, otroCanal: 0, sinFecha: 0, malas: 0, archivos: [] };
    return a;
  }
  // cells en orden: SESSION_ID, CHANNEL, RP_ID, DATE, CUSTOMER_NAME, CUSTOMER_EMAIL, CUSTOMER_PHONE, QUERY, ANSWER, CUSTOMER_ID, CONN_ID, BSUID
  function filaCdr(a, cells, crudo, archivo) {
    if (cells.length < 11) return;            // filas de diseño del reporte (logo, títulos)
    var ses = norm(cells[0]);
    if (!ses) { a.malas++; return; }
    if (/^TOTAL/i.test(ses)) { a.total++; return; }
    a.leidas++;
    var h = cyrb53(crudo);
    if (a.vistos.has(h)) { a.dup++; return; }
    a.vistos.add(h);
    if (low(cells[1]) !== 'whatsapp') { a.otroCanal++; return; }
    var ms = aMs(norm(cells[3]));
    if (ms == null) { a.sinFecha++; return; }
    var fecha = msAFecha(ms);
    var k = fecha + '\u0001' + archivo;
    a.inter[k] = (a.inter[k] || 0) + 1;
    if (!a.archivoDia[fecha]) a.archivoDia[fecha] = archivo;
    var tel = norm(cells[6]);
    var l = a.porCel.get(tel);
    if (!l) a.porCel.set(tel, l = []);
    l.push(ms);
  }
  // HTML (omniexperiencia .xls): se recorre por trozos, sin cargar todo el DOM
  var TD = /<td[^>]*>([\s\S]*?)<\/td>/g;
  function nuevoLectorHtml(ctx, fuente, archivo) {
    var a = acumCdr(ctx, fuente); a.archivos.push(archivo);
    var buf = '';
    function procesar(final) {
      var start = 0;
      while (true) {
        var i = buf.indexOf('<tr', start);
        if (i < 0) { start = final ? buf.length : Math.max(start, buf.length - 3); break; }
        var j = buf.indexOf('</tr>', i);
        if (j < 0) { start = i; break; }
        var tr = buf.slice(i, j);
        start = j + 5;
        if (tr.indexOf('<th') >= 0) continue;
        var cells = [], m;
        TD.lastIndex = 0;
        while ((m = TD.exec(tr)) !== null) cells.push(m[1]);
        filaCdr(a, cells, tr, archivo);
      }
      buf = buf.slice(start);
    }
    return {
      push: function (texto) { buf += texto; procesar(false); },
      fin: function () { procesar(true); buf = ''; }
    };
  }
  // Excel (teleconsulta .xlsx): encabezado en la fila donde la columna A dice SESSION_ID
  function procesarCdrExcel(ctx, XLSX, buf, archivo, fuente) {
    var a = acumCdr(ctx, fuente); a.archivos.push(archivo);
    var aoa = leerHoja(XLSX, buf);
    var fila = -1;
    for (var i = 0; i < Math.min(aoa.length, 60); i++) if (aoa[i] && norm(aoa[i][0]) === 'SESSION_ID') { fila = i; break; }
    if (fila < 0) throw new Error('No encontré la fila de encabezado SESSION_ID. ¿Es el reporte "CDR Routing interacciones y chatbots"?');
    var orden = ['SESSION_ID', 'CHANNEL', 'RP_ID', 'DATE', 'CUSTOMER_NAME', 'CUSTOMER_EMAIL', 'CUSTOMER_PHONE', 'CUSTOMER_QUERY', 'ROUTING_ANSWER', 'CUSTOMER_ID', 'CONN_ID', 'BSUID'];
    var idx = indices(aoa[fila], orden);
    ['SESSION_ID', 'CHANNEL', 'DATE', 'CUSTOMER_PHONE'].forEach(function (k) { if (idx[k] < 0) throw new Error('Falta la columna ' + k + ' en ' + archivo); });
    for (var r = fila + 1; r < aoa.length; r++) {
      var row = aoa[r]; if (!row) continue;
      var cells = orden.map(function (k) {
        var v = idx[k] >= 0 ? row[idx[k]] : '';
        if (k === 'DATE' && typeof v === 'number') {
          var p = XLSX.SSF.parse_date_code(v);
          v = ymd(p.y, p.m, p.d) + ' ' + pad(p.H) + ':' + pad(p.M) + ':' + pad(Math.floor(p.S));
        }
        return v == null ? '' : String(v);
      });
      filaCdr(a, cells, cells.join('\u0001'), archivo);
    }
  }
  function cerrarCdr(ctx, fuente) {
    var a = ctx.cdr[fuente];
    var lim = ctx.ventanaHoras * 3600000;
    var conv = {};
    a.porCel.forEach(function (l) {
      l.sort(function (x, y) { return x - y; });
      var ini = null;
      for (var i = 0; i < l.length; i++) {
        if (ini === null || l[i] - ini > lim) { ini = l[i]; var f = msAFecha(ini); conv[f] = (conv[f] || 0) + 1; }
      }
    });
    var totInter = 0, totConv = 0;
    Object.keys(a.inter).forEach(function (k) {
      var p = k.split('\u0001');
      sumarCdr(ctx, fuente, p[1], p[0], 'Interacciones', 'Interacción', a.inter[k]);
      totInter += a.inter[k];
    });
    Object.keys(conv).forEach(function (f) {
      sumarCdr(ctx, fuente, a.archivoDia[f] || a.archivos[0], f, 'Conversaciones', 'Conversación ' + ctx.ventanaHoras + 'h', conv[f]);
      totConv += conv[f];
    });
    log(ctx, fuente, 'Filas leídas', a.leidas, a.archivos.join(' + '));
    if (a.total) log(ctx, fuente, 'Fila TOTAL del reporte eliminada', a.total);
    log(ctx, fuente, 'Duplicados exactos eliminados', a.dup);
    log(ctx, fuente, 'Filas de prueba u otro canal eliminadas (test_chat_bot)', a.otroCanal);
    if (a.sinFecha) log(ctx, fuente, 'Filas sin fecha (descartadas)', a.sinFecha);
    if (a.malas) log(ctx, fuente, 'Filas con formato incompleto (descartadas)', a.malas);
    log(ctx, fuente, 'Interacciones del bot', totInter);
    log(ctx, fuente, 'Conversaciones de ' + ctx.ventanaHoras + ' h calculadas', totConv, 'celulares únicos: ' + fmt(a.porCel.size));
    a.vistos = null; a.porCel = null;
  }
  function sumarCdr(ctx, fuente, archivo, fecha, valor, estado, cant) {
    var k = [fuente, archivo, fecha, valor, estado, 1].join('\u0001');
    ctx.grupos[k] = { FUENTE: fuente, ARCHIVO: archivo, FECHA: fecha, CAMPAÑA: 'Chatbot', VALOR_ORIGEN: valor, ESTADO: estado, ES_FACTURABLE: 1, CANTIDAD: cant, REGISTROS: cant };
  }

  // ------------------------------------------------------------ cierre de la corrida
  function lote(fecha) {
    var d = fecha || new Date();
    return Number('' + d.getFullYear() + pad(d.getMonth() + 1) + pad(d.getDate()) + pad(d.getHours()) + pad(d.getMinutes()));
  }
  // Search Key, cliente, campaña, servicio, canal y estado de homologación de una fila
  function homologar(r, asignaciones) {
    var t = TIPOS[r.FUENTE];
    var k = r.FUENTE + '|' + clave(r.VALOR_ORIGEN), kGen = r.FUENTE + '|*';
    var man = asignaciones && (asignaciones[k] || null);
    var m = MAPEO[k] || MAPEO[kGen];
    var sk = null, h = null, nota = '';
    if (man) { sk = man; h = 'Homologado (manual)'; }
    else if (m) { sk = m.sk; h = m.h; nota = m.nota || ''; }
    else {
      // Regla automática: la campaña del proveedor ya trae "Cliente_Campaña" (o el Search Key completo) y el canal coincide
      var cv = clave(r.VALOR_ORIGEN), cf = CANAL_FUENTE[r.FUENTE];
      var hit = (catalogo.lineas || []).filter(function (l) {
        var pt = partesSK(l.sk);
        return clave(l.sk) === cv || (clave(pt.cliente + '_' + pt.campana) === cv && l.canal === cf);
      });
      if (hit.length === 1) { sk = hit[0].sk; h = 'Homologado'; nota = 'Regla automática: la campaña del proveedor coincide con cliente y campaña del ppto.'; }
    }
    if (sk) {
      var cat = buscarSK(sk);
      if (cat) sk = cat.sk;
      else { h = 'Por confirmar'; nota = 'El Search Key no está en el pptoAjustado cargado en la app.'; }
      var pt2 = partesSK(sk);
      r['Search_Key'] = sk;
      r.CLIENTE = nombreCliente(pt2.cliente); r['CAMPAÑA'] = pt2.campana; r.SERVICIO = pt2.servicio;
      r.CANAL = (cat && cat.canal) || canalDe(pt2.servicio) || CANAL_FUENTE[r.FUENTE];
    } else {
      r['Search_Key'] = 'SIN HOMOLOGAR_' + t.proveedor + '_' + r.VALOR_ORIGEN;
      r.CLIENTE = 'Sin asignar'; r['CAMPAÑA'] = ''; r.SERVICIO = ''; r.CANAL = CANAL_FUENTE[r.FUENTE];
      h = 'No homologado'; nota = 'Campaña nueva: elija su Search Key en la app antes de copiar.';
    }
    r.HOMOLOGACION = h; r.NOTA_HOMOLOGACION = nota;
    if (m) { r.SUBCANAL = m.sub; r.UNIDAD = m.unidad; }
    else {
      r.SUBCANAL = r.FUENTE === 'TOPPOINT' ? (/^sms/i.test(String(r.VALOR_ORIGEN)) ? 'SMS' : 'Email') :
        r.FUENTE === 'NUVETO_AVI' ? 'Llamada' : (r.FUENTE === 'OMNI_WA' || r.FUENTE === 'TELECONSULTA_WA') ? 'WhatsApp' : CANAL_FUENTE[r.FUENTE];
      r.UNIDAD = r.FUENTE === 'YESBPO_SMS' ? 'SMS (segmento)' : r.FUENTE === 'NUVETO_AVI' ? 'Minuto' : (r.SUBCANAL === 'Email' ? 'Correo' : r.SUBCANAL === 'SMS' ? 'SMS' : 'Unidad');
    }
    return r;
  }
  // Campañas que quedaron sin Search Key, con los Search Keys del catálogo que se le pueden asignar
  function pendientes(filas) {
    var p = {};
    filas.forEach(function (r) {
      if (r.HOMOLOGACION !== 'No homologado') return;
      var k = r.FUENTE + '|' + clave(r.VALOR_ORIGEN);
      var x = p[k] || (p[k] = { clave: k, fuente: r.FUENTE, formato: TIPOS[r.FUENTE].nombre, valor: r.VALOR_ORIGEN, cantidad: 0, filas: 0 });
      x.cantidad += r.ES_FACTURABLE ? r.CANTIDAD : 0; x.filas++;
    });
    return Object.keys(p).map(function (k) {
      var x = p[k], cf = CANAL_FUENTE[x.fuente];
      x.opciones = (catalogo.lineas || []).slice().sort(function (a, b) {
        var pa = a.canal === cf ? 0 : 1, pb = b.canal === cf ? 0 : 1;
        return pa - pb || (a.sk < b.sk ? -1 : 1);
      }).map(function (l) { return { sk: l.sk, canal: l.canal, sugerido: l.canal === cf }; });
      return x;
    });
  }
  function rehomologar(filas, asignaciones) { filas.forEach(function (r) { homologar(r, asignaciones); }); return pendientes(filas); }

  function finalizar(ctx, loteNum, asignaciones) {
    Object.keys(ctx.cdr).forEach(function (f) { if (ctx.cdr[f].porCel) cerrarCdr(ctx, f); });
    var filas = Object.keys(ctx.grupos).map(function (k) { return ctx.grupos[k]; });
    filas.forEach(function (r) { if (r._seg !== undefined) { r.CANTIDAD = Math.round(r._seg / 60); delete r._seg; } r.HOJA = hojaDe(r.FUENTE); });
    var corte = {};
    filas.forEach(function (r) { if (!corte[r.FUENTE] || r.FECHA > corte[r.FUENTE]) corte[r.FUENTE] = r.FECHA; });
    filas.forEach(function (r) {
      var y = +r.FECHA.slice(0, 4), mes = +r.FECHA.slice(5, 7);
      r.AÑO = y; r.NRO_MES = mes; r.MES = MESES[mes - 1];
      r.PROVEEDOR = TIPOS[r.FUENTE].proveedor;
      if (r['CAMPAÑA_PROVEEDOR'] === undefined) r['CAMPAÑA_PROVEEDOR'] = r['CAMPAÑA'];
      homologar(r, asignaciones);
      r.FECHA_CORTE = corte[r.FUENTE];
      r.LOTE = loteNum;
    });
    pendientes(filas).forEach(function (x) {
      aviso(ctx, 'alto', 'Campaña nueva sin Search Key: "' + x.valor + '" (' + x.formato + ', ' + fmt(x.cantidad) + ' unidades). Asígnele su Search Key en "Campañas sin Search Key" antes de copiar.');
    });
    var notas = {};
    filas.forEach(function (r) { if (r.HOMOLOGACION === 'Por confirmar' && r.NOTA_HOMOLOGACION) notas[r.NOTA_HOMOLOGACION] = 1; });
    Object.keys(notas).forEach(function (n) { aviso(ctx, 'info', 'Search Key por confirmar · ' + n); });
    filas.sort(function (a, b) {
      return a.FUENTE < b.FUENTE ? -1 : a.FUENTE > b.FUENTE ? 1 : a['Search_Key'] < b['Search_Key'] ? -1 : a['Search_Key'] > b['Search_Key'] ? 1 :
        a.FECHA < b.FECHA ? -1 : a.FECHA > b.FECHA ? 1 : String(a['CAMPAÑA_PROVEEDOR']) < String(b['CAMPAÑA_PROVEEDOR']) ? -1 :
          String(a['CAMPAÑA_PROVEEDOR']) > String(b['CAMPAÑA_PROVEEDOR']) ? 1 : a.ESTADO < b.ESTADO ? -1 : a.ESTADO > b.ESTADO ? 1 : 0;
    });
    return filas;
  }
  function resumen(filas) {
    var r = {};
    filas.forEach(function (f) {
      var k = f['Search_Key'];
      var x = r[k] || (r[k] = { key: k, cliente: f.CLIENTE, canal: f.CANAL, homolog: f.HOMOLOGACION, fuente: f.FUENTE, proveedor: f.PROVEEDOR,
        unidad: f.UNIDAD, fact: 0, nofact: 0, registros: 0, desde: f.FECHA, hasta: f.FECHA, porMes: {} });
      if (f.UNIDAD && x.unidad.split(' / ').indexOf(f.UNIDAD) < 0) x.unidad += ' / ' + f.UNIDAD;
      if (f.ES_FACTURABLE) { x.fact += f.CANTIDAD; x.porMes[f.NRO_MES] = (x.porMes[f.NRO_MES] || 0) + f.CANTIDAD; } else x.nofact += f.CANTIDAD;
      x.registros += f.REGISTROS;
      if (f.FECHA < x.desde) x.desde = f.FECHA;
      if (f.FECHA > x.hasta) x.hasta = f.FECHA;
      if (f.HOMOLOGACION !== x.homolog && (f.HOMOLOGACION === 'No homologado' || f.HOMOLOGACION === 'Por confirmar')) x.homolog = f.HOMOLOGACION;
    });
    return Object.keys(r).map(function (k) {
      var x = r[k], cat = buscarSK(k), mes = +x.hasta.slice(5, 7);
      x.mesTope = MESES[mes - 1];
      x.tope = cat && cat.q ? cat.q[mes - 1] : null;
      x.realMes = x.porMes[mes] || 0;
      delete x.porMes;
      return x;
    });
  }
  function aTsv(filas) {
    return filas.map(function (f) {
      return COLUMNAS.map(function (c) {
        var v = f[c];
        if (v == null) return '';
        return String(v).replace(/[\t\r\n]+/g, ' ');
      }).join('\t');
    }).join('\r\n');
  }

  function porHoja(filas) {
    return HOJAS.map(function (h) {
      var f = filas.filter(function (r) { return r.FUENTE === h.fuente; });
      var desde = null, hasta = null;
      f.forEach(function (r) { if (!desde || r.FECHA < desde) desde = r.FECHA; if (!hasta || r.FECHA > hasta) hasta = r.FECHA; });
      return { hoja: h.hoja, fuente: h.fuente, nombre: TIPOS[h.fuente].nombre, filas: f, desde: desde, hasta: hasta };
    });
  }

  var api = {
    MESES: MESES, TIPOS: TIPOS, MAPEO: MAPEO, CANAL_FUENTE: CANAL_FUENTE, COLUMNAS: COLUMNAS, HOJAS: HOJAS, porHoja: porHoja, procesarNuveto: procesarNuveto,
    clave: clave, canalDe: canalDe, partesSK: partesSK, setCatalogo: setCatalogo, getCatalogo: getCatalogo, buscarSK: buscarSK,
    leerCatalogoPpto: leerCatalogoPpto, homologar: homologar, rehomologar: rehomologar, pendientes: pendientes,
    detectarPorNombre: detectarPorNombre, detectarPorContenido: detectarPorContenido, detectarLibro: detectarLibro,
    nuevoContexto: nuevoContexto, procesarYesbpoSms: procesarYesbpoSms, procesarYesbpoMailing: procesarYesbpoMailing,
    procesarToppoint: procesarToppoint, nuevoLectorHtml: nuevoLectorHtml, procesarCdrExcel: procesarCdrExcel,
    finalizar: finalizar, resumen: resumen, aTsv: aTsv, lote: lote, fmt: fmt
  };
  root.ConsumosEngine = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof window !== 'undefined' ? window : globalThis);
