/* Catálogo de Search Keys de consumo (pptoAjustado). Se reemplaza al cargar RealConsolidado2026 en la app. */
(function (root) {
  var CATALOGO = {
 "origen": "RealConsolidado2026_1.xlsx · pptoAjustado",
 "fecha": "2026-09-30",
 "lineas": [
  {
   "sk": "Medplus_Atención Canales de servicio al cliente_Email",
   "cliente": "MedPlus",
   "campana": "Atención Canales de servicio al cliente",
   "servicio": "Email",
   "canal": "Email",
   "q": [
    350000.0,
    350000.0,
    350000.0,
    350000.0,
    350000.0,
    350000.0,
    350000.0,
    350000.0,
    350000.0,
    350000.0,
    350000.0,
    350000.0
   ]
  },
  {
   "sk": "Medplus_Atención Canales de servicio al cliente_Whatsapp CIMA_Mensaje Entrante/Saliente",
   "cliente": "MedPlus",
   "campana": "Atención Canales de servicio al cliente",
   "servicio": "Whatsapp CIMA_Mensaje Entrante/Saliente",
   "canal": "WhatsApp",
   "q": [
    1000.0,
    1000.0,
    1000.0,
    1000.0,
    1000.0,
    1000.0,
    1000.0,
    1000.0,
    1000.0,
    1000.0,
    1000.0,
    1000.0
   ]
  },
  {
   "sk": "Medplus_Atención Canales de servicio al cliente_VoiceBot_Campañas",
   "cliente": "MedPlus",
   "campana": "Atención Canales de servicio al cliente",
   "servicio": "VoiceBot_Campañas",
   "canal": "Voicebot (AVI)",
   "q": [
    500.0,
    500.0,
    500.0,
    500.0,
    500.0,
    500.0,
    500.0,
    500.0,
    500.0,
    500.0,
    500.0,
    500.0
   ]
  },
  {
   "sk": "Medplus_Asistente Virtual_Conversacion Whatsapp 24H Interaccion",
   "cliente": "MedPlus",
   "campana": "Asistente Virtual",
   "servicio": "Conversacion Whatsapp 24H Interaccion",
   "canal": "WhatsApp",
   "q": [
    45000.0,
    45000.0,
    45000.0,
    45000.0,
    45000.0,
    45000.0,
    45000.0,
    45000.0,
    45000.0,
    45000.0,
    45000.0,
    45000.0
   ]
  },
  {
   "sk": "Medplus_Asistente Virtual_Chatbot [Cada respuesta]",
   "cliente": "MedPlus",
   "campana": "Asistente Virtual",
   "servicio": "Chatbot [Cada respuesta]",
   "canal": "Chatbot",
   "q": [
    290000.0,
    290000.0,
    290000.0,
    290000.0,
    290000.0,
    290000.0,
    290000.0,
    290000.0,
    290000.0,
    290000.0,
    290000.0,
    290000.0
   ]
  },
  {
   "sk": "Medplus_Agendamiento de Citas Comerciales_Mensajes de Texto",
   "cliente": "MedPlus",
   "campana": "Agendamiento de Citas Comerciales",
   "servicio": "Mensajes de Texto",
   "canal": "SMS",
   "q": [
    300.0,
    300.0,
    300.0,
    300.0,
    300.0,
    300.0,
    300.0,
    300.0,
    300.0,
    300.0,
    300.0,
    300.0
   ]
  },
  {
   "sk": "Medplus_Cobranza_Email",
   "cliente": "MedPlus",
   "campana": "Cobranza",
   "servicio": "Email",
   "canal": "Email",
   "q": [
    500.0,
    500.0,
    500.0,
    500.0,
    500.0,
    500.0,
    500.0,
    500.0,
    500.0,
    500.0,
    500.0,
    500.0
   ]
  },
  {
   "sk": "Medplus_Cobranza_Mensajes de Texto",
   "cliente": "MedPlus",
   "campana": "Cobranza",
   "servicio": "Mensajes de Texto",
   "canal": "SMS",
   "q": [
    125000.0,
    125000.0,
    125000.0,
    125000.0,
    125000.0,
    125000.0,
    125000.0,
    125000.0,
    125000.0,
    125000.0,
    125000.0,
    125000.0
   ]
  },
  {
   "sk": "Medplus_Atención Canales de servicio al cliente_Mensajes de Texto",
   "cliente": "MedPlus",
   "campana": "Atención Canales de servicio al cliente",
   "servicio": "Mensajes de Texto",
   "canal": "SMS",
   "q": [
    90000.0,
    90000.0,
    90000.0,
    90000.0,
    90000.0,
    90000.0,
    90000.0,
    90000.0,
    90000.0,
    90000.0,
    90000.0,
    90000.0
   ]
  },
  {
   "sk": "Medplus_Encuestas de Satisfaccion Aseguramiento_Mensajes de Texto",
   "cliente": "MedPlus",
   "campana": "Encuestas de Satisfaccion Aseguramiento",
   "servicio": "Mensajes de Texto",
   "canal": "SMS",
   "q": [
    100000.0,
    100000.0,
    100000.0,
    100000.0,
    100000.0,
    100000.0,
    100000.0,
    100000.0,
    100000.0,
    100000.0,
    100000.0,
    100000.0
   ]
  },
  {
   "sk": "Medplus_Agendamiento de Servicios Medico Domiciliario_Mensajes de Texto",
   "cliente": "MedPlus",
   "campana": "Agendamiento de Servicios Medico Domiciliario",
   "servicio": "Mensajes de Texto",
   "canal": "SMS",
   "q": [
    8500.0,
    8500.0,
    8500.0,
    8500.0,
    8500.0,
    8500.0,
    8500.0,
    8500.0,
    8500.0,
    8500.0,
    8500.0,
    8500.0
   ]
  },
  {
   "sk": "Clinica azul_Agendamiento de citas_Mensajes de Texto",
   "cliente": "Clínica Azul",
   "campana": "Agendamiento de citas",
   "servicio": "Mensajes de Texto",
   "canal": "SMS",
   "q": [
    1000.0,
    1000.0,
    1000.0,
    1000.0,
    1000.0,
    1000.0,
    1000.0,
    1000.0,
    1000.0,
    1000.0,
    1000.0,
    1000.0
   ]
  },
  {
   "sk": "Clinica azul_Agendamiento de citas_Email",
   "cliente": "Clínica Azul",
   "campana": "Agendamiento de citas",
   "servicio": "Email",
   "canal": "Email",
   "q": [
    1000.0,
    1000.0,
    1000.0,
    1000.0,
    1000.0,
    1000.0,
    1000.0,
    1000.0,
    1000.0,
    1000.0,
    1000.0,
    1000.0
   ]
  },
  {
   "sk": "Clinica azul_Agendamiento de citas_Bot Confirmacion Citas",
   "cliente": "Clínica Azul",
   "campana": "Agendamiento de citas",
   "servicio": "Bot Confirmacion Citas",
   "canal": "Bot de agenda",
   "q": [
    1000.0,
    1000.0,
    1000.0,
    1000.0,
    1000.0,
    1000.0,
    1000.0,
    1000.0,
    1000.0,
    1000.0,
    1000.0,
    1000.0
   ]
  },
  {
   "sk": "Clinica azul_Agendamiento de citas_Whatsapp CIMA_Mensaje Entrante/Saliente",
   "cliente": "Clínica Azul",
   "campana": "Agendamiento de citas",
   "servicio": "Whatsapp CIMA_Mensaje Entrante/Saliente",
   "canal": "WhatsApp",
   "q": [
    3000.0,
    3000.0,
    3000.0,
    3000.0,
    3000.0,
    3000.0,
    3000.0,
    3000.0,
    3000.0,
    3000.0,
    3000.0,
    3000.0
   ]
  },
  {
   "sk": "Bluecare_Agendamiento de citas_Mensajes de Texto",
   "cliente": "BlueCare",
   "campana": "Agendamiento de citas",
   "servicio": "Mensajes de Texto",
   "canal": "SMS",
   "q": [
    1000.0,
    1000.0,
    1000.0,
    1000.0,
    1000.0,
    1000.0,
    1000.0,
    1000.0,
    1000.0,
    1000.0,
    1000.0,
    1000.0
   ]
  },
  {
   "sk": "Bluecare_Agendamiento Inteligente_Chatbot [Cada respuesta]",
   "cliente": "BlueCare",
   "campana": "Agendamiento Inteligente",
   "servicio": "Chatbot [Cada respuesta]",
   "canal": "Chatbot",
   "q": [
    25000.0,
    25000.0,
    25000.0,
    25000.0,
    25000.0,
    25000.0,
    25000.0,
    25000.0,
    25000.0,
    25000.0,
    25000.0,
    25000.0
   ]
  },
  {
   "sk": "Bluecare_Agendamiento Inteligente_Conversacion Whatsapp 24H Interaccion",
   "cliente": "BlueCare",
   "campana": "Agendamiento Inteligente",
   "servicio": "Conversacion Whatsapp 24H Interaccion",
   "canal": "WhatsApp",
   "q": [
    10000.0,
    10000.0,
    10000.0,
    10000.0,
    10000.0,
    10000.0,
    10000.0,
    10000.0,
    10000.0,
    10000.0,
    10000.0,
    10000.0
   ]
  },
  {
   "sk": "Bluecare_Encuestas de Satisfaccion Prestacion_Encuesta Email - SMS",
   "cliente": "BlueCare",
   "campana": "Encuestas de Satisfaccion Prestacion",
   "servicio": "Encuesta Email - SMS",
   "canal": "SMS + Email",
   "q": [
    17560.0,
    17560.0,
    17560.0,
    17560.0,
    17560.0,
    17560.0,
    17560.0,
    17560.0,
    17560.0,
    17560.0,
    17560.0,
    17560.0
   ]
  },
  {
   "sk": "Bluecare_Gestion Ordenamiento_Bot Confirmacion Citas",
   "cliente": "BlueCare",
   "campana": "Gestion Ordenamiento",
   "servicio": "Bot Confirmacion Citas",
   "canal": "Bot de agenda",
   "q": [
    25000.0,
    25000.0,
    25000.0,
    25000.0,
    25000.0,
    25000.0,
    25000.0,
    25000.0,
    25000.0,
    25000.0,
    25000.0,
    25000.0
   ]
  },
  {
   "sk": "Bluecare_Proceso de novedades y apertura de agendas médicas_Mensajes de Texto",
   "cliente": "BlueCare",
   "campana": "Proceso de novedades y apertura de agendas médicas",
   "servicio": "Mensajes de Texto",
   "canal": "SMS",
   "q": [
    1030.0,
    1030.0,
    1030.0,
    1030.0,
    1030.0,
    1030.0,
    1030.0,
    1030.0,
    1030.0,
    1030.0,
    1030.0,
    1030.0
   ]
  }
 ]
};
  if (typeof module === 'object' && module.exports) module.exports = CATALOGO; else root.ConsumosCatalogo = CATALOGO;
})(typeof self !== 'undefined' ? self : this);
